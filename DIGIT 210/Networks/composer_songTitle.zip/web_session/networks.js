var networks = {"composer_songtitle": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "network3.tsv",
    "name" : "composer_songtitle",
    "SUID" : 2873,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "2915",
        "shared_name" : "Alan Menken",
        "name" : "Alan Menken",
        "song_title" : "",
        "SUID" : 2915,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 274.3297325850106,
        "y" : 538.8562074633475
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2914",
        "shared_name" : "One Jump Ahead (Reprise)",
        "name" : "One Jump Ahead (Reprise)",
        "song_title" : "song title",
        "SUID" : 2914,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 268.40102260590055,
        "y" : 244.19449899214206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2913",
        "shared_name" : "One Jump Ahead",
        "name" : "One Jump Ahead",
        "song_title" : "song title",
        "SUID" : 2913,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 432.1782137320069,
        "y" : 633.1285806509042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2912",
        "shared_name" : "A Whole New World",
        "name" : "A Whole New World",
        "song_title" : "song title",
        "SUID" : 2912,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -380.145489323288,
        "y" : 462.46600732499286
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2911",
        "shared_name" : "Speechless (Full-live)",
        "name" : "Speechless (Full-live)",
        "song_title" : "song title",
        "SUID" : 2911,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -376.2764898850455,
        "y" : -260.081090678131
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2910",
        "shared_name" : "Forget About Love",
        "name" : "Forget About Love",
        "song_title" : "song title",
        "SUID" : 2910,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -2.2565737462337268,
        "y" : -213.36876425568593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2909",
        "shared_name" : "Father and Son",
        "name" : "Father and Son",
        "song_title" : "song title",
        "SUID" : 2909,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 282.57010630274925,
        "y" : 114.15283696281384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2908",
        "shared_name" : "Out of Thin Air",
        "name" : "Out of Thin Air",
        "song_title" : "song title",
        "SUID" : 2908,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -555.6938793531988,
        "y" : -377.4812270023356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "shared_name" : "Nothing In The World (Quite Like A Friend)(1994)",
        "name" : "Nothing In The World (Quite Like A Friend)(1994)",
        "song_title" : "song title",
        "SUID" : 2907,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 886.0147684597457,
        "y" : 194.21435430776802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2906",
        "shared_name" : "One Jump Ahead (animated)",
        "name" : "One Jump Ahead (animated)",
        "song_title" : "song title",
        "SUID" : 2906,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -112.83900306654328,
        "y" : -68.92257793879028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "shared_name" : "One Jump Ahead Reprise-animated",
        "name" : "One Jump Ahead Reprise-animated",
        "song_title" : "song title",
        "SUID" : 2905,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 922.6180321417664,
        "y" : -34.23759849311486
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2904",
        "shared_name" : "Prince Ali",
        "name" : "Prince Ali",
        "song_title" : "song title",
        "SUID" : 2904,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -200.10640205662875,
        "y" : 321.98636293598986
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2903",
        "shared_name" : "Arabian Nights (2019)",
        "name" : "Arabian Nights (2019)",
        "song_title" : "song title",
        "SUID" : 2903,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 729.1105351797812,
        "y" : -60.257718094005746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2902",
        "shared_name" : "Friend Like Me(Live Action)",
        "name" : "Friend Like Me(Live Action)",
        "song_title" : "song title",
        "SUID" : 2902,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -278.4857340144306,
        "y" : 120.39544831710106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2901",
        "shared_name" : "Prince Ali (Reprise)",
        "name" : "Prince Ali (Reprise)",
        "song_title" : "song title",
        "SUID" : 2901,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 171.89222374329958,
        "y" : 187.30658670406768
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2900",
        "shared_name" : "You're Only Second Rate(1994)",
        "name" : "You're Only Second Rate(1994)",
        "song_title" : "song title",
        "SUID" : 2900,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -198.13756482404588,
        "y" : -326.65113666864517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "shared_name" : "Friend Like Me(Animated)",
        "name" : "Friend Like Me(Animated)",
        "song_title" : "song title",
        "SUID" : 2899,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 645.9581414934919,
        "y" : -306.9867984361615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2898",
        "shared_name" : "Arabian Nights",
        "name" : "Arabian Nights",
        "song_title" : "song title",
        "SUID" : 2898,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -291.1922754451925,
        "y" : 673.0534608167435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2897",
        "shared_name" : "Howard Ashman",
        "name" : "Howard Ashman",
        "song_title" : "",
        "SUID" : 2897,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 514.2232627072608,
        "y" : 569.442914036589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2896",
        "shared_name" : "Benj Pasek",
        "name" : "Benj Pasek",
        "song_title" : "",
        "SUID" : 2896,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : -212.31655854828688,
        "y" : -207.0547397393463
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2895",
        "shared_name" : "Justin Paul",
        "name" : "Justin Paul",
        "song_title" : "",
        "SUID" : 2895,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : -230.93219438574297,
        "y" : -58.61001729258018
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2894",
        "shared_name" : "One Jump Ahead (Reprise 2)",
        "name" : "One Jump Ahead (Reprise 2)",
        "song_title" : "song title",
        "SUID" : 2894,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -360.48128513213084,
        "y" : 151.09268049530124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "shared_name" : "Patty Silversher",
        "name" : "Patty Silversher",
        "song_title" : "",
        "SUID" : 2893,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : -43.33184067167769,
        "y" : -325.35757965196666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2892",
        "shared_name" : "I'm Looking Out For Me(1994)",
        "name" : "I'm Looking Out For Me(1994)",
        "song_title" : "song title",
        "SUID" : 2892,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -302.13508812021473,
        "y" : -515.6549364433259
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2891",
        "shared_name" : "Michael Silversher",
        "name" : "Michael Silversher",
        "song_title" : "",
        "SUID" : 2891,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 69.11230641969041,
        "y" : 637.8053873452733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2890",
        "shared_name" : "Randy Petersen",
        "name" : "Randy Petersen",
        "song_title" : "",
        "SUID" : 2890,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 182.24866438201946,
        "y" : -543.184584995643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2889",
        "shared_name" : "Are You in or Out?",
        "name" : "Are You in or Out?",
        "song_title" : "song title",
        "SUID" : 2889,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -358.6999203362419,
        "y" : -113.68386915871973
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2888",
        "shared_name" : "There's a Party Here in Agrabah",
        "name" : "There's a Party Here in Agrabah",
        "song_title" : "song title",
        "SUID" : 2888,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : 533.7428974844139,
        "y" : 5.875765563668841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2887",
        "shared_name" : "Welcome to the Forty Thieves",
        "name" : "Welcome to the Forty Thieves",
        "song_title" : "song title",
        "SUID" : 2887,
        "composer" : "",
        "selected" : false
      },
      "position" : {
        "x" : -403.582344988749,
        "y" : -5.954643693688105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2886",
        "shared_name" : "Kevin Quinn",
        "name" : "Kevin Quinn",
        "song_title" : "",
        "SUID" : 2886,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : -422.9377296024266,
        "y" : 275.597801306006
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2885",
        "shared_name" : "Dale Gonyea",
        "name" : "Dale Gonyea",
        "song_title" : "",
        "SUID" : 2885,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 465.2544078382199,
        "y" : -421.23565591565176
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2884",
        "shared_name" : "David Friedman",
        "name" : "David Friedman",
        "song_title" : "",
        "SUID" : 2884,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 721.8055742974984,
        "y" : -165.48763671354519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2883",
        "shared_name" : "Tim Rice",
        "name" : "Tim Rice",
        "song_title" : "",
        "SUID" : 2883,
        "composer" : "composer",
        "selected" : false
      },
      "position" : {
        "x" : 582.0220946482934,
        "y" : 141.34969939628155
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "4249",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4249,
        "BEND_MAP_ID" : 4249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4248",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4248,
        "BEND_MAP_ID" : 4248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4247",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4247,
        "BEND_MAP_ID" : 4247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4246",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4246,
        "BEND_MAP_ID" : 4246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4245",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4245,
        "BEND_MAP_ID" : 4245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4244",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4244,
        "BEND_MAP_ID" : 4244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4243",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4243,
        "BEND_MAP_ID" : 4243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4242",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4242,
        "BEND_MAP_ID" : 4242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4241",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4241,
        "BEND_MAP_ID" : 4241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4240",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4240,
        "BEND_MAP_ID" : 4240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4239",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4239,
        "BEND_MAP_ID" : 4239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4238",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4238,
        "BEND_MAP_ID" : 4238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4237",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4237,
        "BEND_MAP_ID" : 4237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4236",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4236,
        "BEND_MAP_ID" : 4236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4235",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4235,
        "BEND_MAP_ID" : 4235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4234",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4234,
        "BEND_MAP_ID" : 4234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4233",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4233,
        "BEND_MAP_ID" : 4233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4232",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4232,
        "BEND_MAP_ID" : 4232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4231",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4231,
        "BEND_MAP_ID" : 4231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4230",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4230,
        "BEND_MAP_ID" : 4230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4229",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4229,
        "BEND_MAP_ID" : 4229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4228",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4228,
        "BEND_MAP_ID" : 4228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4227",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4227,
        "BEND_MAP_ID" : 4227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4226",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4226,
        "BEND_MAP_ID" : 4226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4225",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4225,
        "BEND_MAP_ID" : 4225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4224",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4224,
        "BEND_MAP_ID" : 4224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4223",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4223,
        "BEND_MAP_ID" : 4223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4222",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4222,
        "BEND_MAP_ID" : 4222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4221",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4221,
        "BEND_MAP_ID" : 4221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4220",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4220,
        "BEND_MAP_ID" : 4220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4219",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4219,
        "BEND_MAP_ID" : 4219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4218",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4218,
        "BEND_MAP_ID" : 4218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4217",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4217,
        "BEND_MAP_ID" : 4217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4216",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4216,
        "BEND_MAP_ID" : 4216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4215",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4215,
        "BEND_MAP_ID" : 4215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4214",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4214,
        "BEND_MAP_ID" : 4214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4213",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4213,
        "BEND_MAP_ID" : 4213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4212",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4212,
        "BEND_MAP_ID" : 4212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4211",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4211,
        "BEND_MAP_ID" : 4211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4210",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4210,
        "BEND_MAP_ID" : 4210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4209",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4209,
        "BEND_MAP_ID" : 4209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4208",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4208,
        "BEND_MAP_ID" : 4208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4207",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4207,
        "BEND_MAP_ID" : 4207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4206",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4206,
        "BEND_MAP_ID" : 4206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4205",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4205,
        "BEND_MAP_ID" : 4205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4204",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4204,
        "BEND_MAP_ID" : 4204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4203",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4203,
        "BEND_MAP_ID" : 4203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4202",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4202,
        "BEND_MAP_ID" : 4202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4201",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4201,
        "BEND_MAP_ID" : 4201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4200",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4200,
        "BEND_MAP_ID" : 4200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4199",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4199,
        "BEND_MAP_ID" : 4199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4198",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4198,
        "BEND_MAP_ID" : 4198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4197",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4197,
        "BEND_MAP_ID" : 4197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4196",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4196,
        "BEND_MAP_ID" : 4196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4195",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4195,
        "BEND_MAP_ID" : 4195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4194",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4194,
        "BEND_MAP_ID" : 4194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4193",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4193,
        "BEND_MAP_ID" : 4193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4192",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4192,
        "BEND_MAP_ID" : 4192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4191",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4191,
        "BEND_MAP_ID" : 4191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4190",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4190,
        "BEND_MAP_ID" : 4190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4189",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4189,
        "BEND_MAP_ID" : 4189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4188",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4188,
        "BEND_MAP_ID" : 4188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4187",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4187,
        "BEND_MAP_ID" : 4187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4186",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4186,
        "BEND_MAP_ID" : 4186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4185",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4185,
        "BEND_MAP_ID" : 4185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4184",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4184,
        "BEND_MAP_ID" : 4184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4183",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4183,
        "BEND_MAP_ID" : 4183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4182",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4182,
        "BEND_MAP_ID" : 4182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4181",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4181,
        "BEND_MAP_ID" : 4181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4180",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4180,
        "BEND_MAP_ID" : 4180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4179",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4179,
        "BEND_MAP_ID" : 4179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4178",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4178,
        "BEND_MAP_ID" : 4178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4177",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4177,
        "BEND_MAP_ID" : 4177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4176",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4176,
        "BEND_MAP_ID" : 4176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4175",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4175,
        "BEND_MAP_ID" : 4175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4174",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4174,
        "BEND_MAP_ID" : 4174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4173",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4173,
        "BEND_MAP_ID" : 4173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4172",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4172,
        "BEND_MAP_ID" : 4172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4171",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4171,
        "BEND_MAP_ID" : 4171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4170",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4170,
        "BEND_MAP_ID" : 4170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4169",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4169,
        "BEND_MAP_ID" : 4169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4168",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4168,
        "BEND_MAP_ID" : 4168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4167",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4167,
        "BEND_MAP_ID" : 4167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4166",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4166,
        "BEND_MAP_ID" : 4166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4165",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4165,
        "BEND_MAP_ID" : 4165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4164",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4164,
        "BEND_MAP_ID" : 4164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4163",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4163,
        "BEND_MAP_ID" : 4163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4162",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4162,
        "BEND_MAP_ID" : 4162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4161",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4161,
        "BEND_MAP_ID" : 4161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4160",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4160,
        "BEND_MAP_ID" : 4160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4159",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4159,
        "BEND_MAP_ID" : 4159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4158",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4158,
        "BEND_MAP_ID" : 4158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4157",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4157,
        "BEND_MAP_ID" : 4157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4156",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4156,
        "BEND_MAP_ID" : 4156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4155",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4155,
        "BEND_MAP_ID" : 4155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4154",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4154,
        "BEND_MAP_ID" : 4154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4153",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4153,
        "BEND_MAP_ID" : 4153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4152",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4152,
        "BEND_MAP_ID" : 4152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4151",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4151,
        "BEND_MAP_ID" : 4151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4150",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4150,
        "BEND_MAP_ID" : 4150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4149",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4149,
        "BEND_MAP_ID" : 4149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4148",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4148,
        "BEND_MAP_ID" : 4148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4147",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4147,
        "BEND_MAP_ID" : 4147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4146",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4146,
        "BEND_MAP_ID" : 4146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4145",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4145,
        "BEND_MAP_ID" : 4145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4144",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4144,
        "BEND_MAP_ID" : 4144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4143",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4143,
        "BEND_MAP_ID" : 4143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4142",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4142,
        "BEND_MAP_ID" : 4142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4141",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4141,
        "BEND_MAP_ID" : 4141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4140",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4140,
        "BEND_MAP_ID" : 4140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4139",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4139,
        "BEND_MAP_ID" : 4139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4138",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4138,
        "BEND_MAP_ID" : 4138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4137",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4137,
        "BEND_MAP_ID" : 4137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4136",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4136,
        "BEND_MAP_ID" : 4136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4135",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4135,
        "BEND_MAP_ID" : 4135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4134",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4134,
        "BEND_MAP_ID" : 4134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4133",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4133,
        "BEND_MAP_ID" : 4133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4132",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4132,
        "BEND_MAP_ID" : 4132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4131",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4131,
        "BEND_MAP_ID" : 4131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4130",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4130,
        "BEND_MAP_ID" : 4130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4129",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4129,
        "BEND_MAP_ID" : 4129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4128",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4128,
        "BEND_MAP_ID" : 4128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4127",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4127,
        "BEND_MAP_ID" : 4127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4126",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4126,
        "BEND_MAP_ID" : 4126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4125",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4125,
        "BEND_MAP_ID" : 4125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4124",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4124,
        "BEND_MAP_ID" : 4124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4123",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4123,
        "BEND_MAP_ID" : 4123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4122",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4122,
        "BEND_MAP_ID" : 4122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4121",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4121,
        "BEND_MAP_ID" : 4121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4120",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4120,
        "BEND_MAP_ID" : 4120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4119",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4119,
        "BEND_MAP_ID" : 4119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4118",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4118,
        "BEND_MAP_ID" : 4118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4117",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4117,
        "BEND_MAP_ID" : 4117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4116",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4116,
        "BEND_MAP_ID" : 4116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4115",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4115,
        "BEND_MAP_ID" : 4115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4114",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4114,
        "BEND_MAP_ID" : 4114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4113",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4113,
        "BEND_MAP_ID" : 4113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4112",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4112,
        "BEND_MAP_ID" : 4112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4111",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4111,
        "BEND_MAP_ID" : 4111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4110",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4110,
        "BEND_MAP_ID" : 4110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4109",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4109,
        "BEND_MAP_ID" : 4109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4108",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4108,
        "BEND_MAP_ID" : 4108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4107",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4107,
        "BEND_MAP_ID" : 4107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4106",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4106,
        "BEND_MAP_ID" : 4106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4105",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4105,
        "BEND_MAP_ID" : 4105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4104",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4104,
        "BEND_MAP_ID" : 4104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4103",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4103,
        "BEND_MAP_ID" : 4103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4102",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4102,
        "BEND_MAP_ID" : 4102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4101",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4101,
        "BEND_MAP_ID" : 4101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4100",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4100,
        "BEND_MAP_ID" : 4100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4099",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4099,
        "BEND_MAP_ID" : 4099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4098",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4098,
        "BEND_MAP_ID" : 4098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4097",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4097,
        "BEND_MAP_ID" : 4097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4096",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4096,
        "BEND_MAP_ID" : 4096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4095",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4095,
        "BEND_MAP_ID" : 4095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4094",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4094,
        "BEND_MAP_ID" : 4094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4093",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4093,
        "BEND_MAP_ID" : 4093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4092",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4092,
        "BEND_MAP_ID" : 4092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4091",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4091,
        "BEND_MAP_ID" : 4091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4090",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4090,
        "BEND_MAP_ID" : 4090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4089",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4089,
        "BEND_MAP_ID" : 4089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4088",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4088,
        "BEND_MAP_ID" : 4088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4087",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4087,
        "BEND_MAP_ID" : 4087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4086",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4086,
        "BEND_MAP_ID" : 4086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4085",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4085,
        "BEND_MAP_ID" : 4085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4084",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4084,
        "BEND_MAP_ID" : 4084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4083",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4083,
        "BEND_MAP_ID" : 4083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4082",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4082,
        "BEND_MAP_ID" : 4082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4081",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4081,
        "BEND_MAP_ID" : 4081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4080",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4080,
        "BEND_MAP_ID" : 4080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4079",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4079,
        "BEND_MAP_ID" : 4079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4078",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4078,
        "BEND_MAP_ID" : 4078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4077",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4077,
        "BEND_MAP_ID" : 4077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4076",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4076,
        "BEND_MAP_ID" : 4076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4075",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4075,
        "BEND_MAP_ID" : 4075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4074",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4074,
        "BEND_MAP_ID" : 4074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4073",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4073,
        "BEND_MAP_ID" : 4073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4072",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4072,
        "BEND_MAP_ID" : 4072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4071",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4071,
        "BEND_MAP_ID" : 4071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4070",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4070,
        "BEND_MAP_ID" : 4070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4069",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4069,
        "BEND_MAP_ID" : 4069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4068",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4068,
        "BEND_MAP_ID" : 4068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4067",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4067,
        "BEND_MAP_ID" : 4067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4066",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4066,
        "BEND_MAP_ID" : 4066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4065",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4065,
        "BEND_MAP_ID" : 4065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4064",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4064,
        "BEND_MAP_ID" : 4064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4063",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4063,
        "BEND_MAP_ID" : 4063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4062",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4062,
        "BEND_MAP_ID" : 4062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4061",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4061,
        "BEND_MAP_ID" : 4061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4060",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4060,
        "BEND_MAP_ID" : 4060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4059",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4059,
        "BEND_MAP_ID" : 4059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4058",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4058,
        "BEND_MAP_ID" : 4058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4057",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4057,
        "BEND_MAP_ID" : 4057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4056",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4056,
        "BEND_MAP_ID" : 4056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4055",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4055,
        "BEND_MAP_ID" : 4055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4054",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4054,
        "BEND_MAP_ID" : 4054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4053",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4053,
        "BEND_MAP_ID" : 4053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4052",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4052,
        "BEND_MAP_ID" : 4052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4051",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4051,
        "BEND_MAP_ID" : 4051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4050",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4050,
        "BEND_MAP_ID" : 4050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4049",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4049,
        "BEND_MAP_ID" : 4049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4048",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4048,
        "BEND_MAP_ID" : 4048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4047",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4047,
        "BEND_MAP_ID" : 4047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4046",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4046,
        "BEND_MAP_ID" : 4046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4045",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4045,
        "BEND_MAP_ID" : 4045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4044",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4044,
        "BEND_MAP_ID" : 4044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4043",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4043,
        "BEND_MAP_ID" : 4043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4042",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4042,
        "BEND_MAP_ID" : 4042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4041",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4041,
        "BEND_MAP_ID" : 4041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4040",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4040,
        "BEND_MAP_ID" : 4040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4039",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4039,
        "BEND_MAP_ID" : 4039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4038",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4038,
        "BEND_MAP_ID" : 4038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4037",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4037,
        "BEND_MAP_ID" : 4037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4036",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4036,
        "BEND_MAP_ID" : 4036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4035",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4035,
        "BEND_MAP_ID" : 4035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4034",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4034,
        "BEND_MAP_ID" : 4034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4033",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4033,
        "BEND_MAP_ID" : 4033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4032",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4032,
        "BEND_MAP_ID" : 4032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4031",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4031,
        "BEND_MAP_ID" : 4031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4030",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4030,
        "BEND_MAP_ID" : 4030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4029",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4029,
        "BEND_MAP_ID" : 4029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4028",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4028,
        "BEND_MAP_ID" : 4028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4027",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4027,
        "BEND_MAP_ID" : 4027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4026",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4026,
        "BEND_MAP_ID" : 4026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4025",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4025,
        "BEND_MAP_ID" : 4025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4024",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4024,
        "BEND_MAP_ID" : 4024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4023",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4023,
        "BEND_MAP_ID" : 4023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4022",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4022,
        "BEND_MAP_ID" : 4022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4021",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4021,
        "BEND_MAP_ID" : 4021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4020",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4020,
        "BEND_MAP_ID" : 4020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4019",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4019,
        "BEND_MAP_ID" : 4019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4018",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 4018,
        "BEND_MAP_ID" : 4018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4017",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4017,
        "BEND_MAP_ID" : 4017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4016",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 4016,
        "BEND_MAP_ID" : 4016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4015",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4015,
        "BEND_MAP_ID" : 4015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4014",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4014,
        "BEND_MAP_ID" : 4014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4013",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 4013,
        "BEND_MAP_ID" : 4013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4012",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 4012,
        "BEND_MAP_ID" : 4012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4011",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 4011,
        "BEND_MAP_ID" : 4011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4010",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4010,
        "BEND_MAP_ID" : 4010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4009",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4009,
        "BEND_MAP_ID" : 4009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4008",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4008,
        "BEND_MAP_ID" : 4008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4007",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 4007,
        "BEND_MAP_ID" : 4007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4006",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4006,
        "BEND_MAP_ID" : 4006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4005",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 4005,
        "BEND_MAP_ID" : 4005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4004",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 4004,
        "BEND_MAP_ID" : 4004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4003",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4003,
        "BEND_MAP_ID" : 4003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4002",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4002,
        "BEND_MAP_ID" : 4002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4001",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4001,
        "BEND_MAP_ID" : 4001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4000",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 4000,
        "BEND_MAP_ID" : 4000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3999",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3999,
        "BEND_MAP_ID" : 3999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3998",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3998,
        "BEND_MAP_ID" : 3998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3997",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3997,
        "BEND_MAP_ID" : 3997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3996",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3996,
        "BEND_MAP_ID" : 3996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3995",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3995,
        "BEND_MAP_ID" : 3995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3994",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3994,
        "BEND_MAP_ID" : 3994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3993",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3993,
        "BEND_MAP_ID" : 3993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3992",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3992,
        "BEND_MAP_ID" : 3992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3991",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3991,
        "BEND_MAP_ID" : 3991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3990",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3990,
        "BEND_MAP_ID" : 3990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3989",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3989,
        "BEND_MAP_ID" : 3989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3988",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3988,
        "BEND_MAP_ID" : 3988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3987",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3987,
        "BEND_MAP_ID" : 3987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3986",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3986,
        "BEND_MAP_ID" : 3986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3985",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3985,
        "BEND_MAP_ID" : 3985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3984",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3984,
        "BEND_MAP_ID" : 3984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3983",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3983,
        "BEND_MAP_ID" : 3983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3982",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3982,
        "BEND_MAP_ID" : 3982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3981",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3981,
        "BEND_MAP_ID" : 3981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3980",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3980,
        "BEND_MAP_ID" : 3980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3979",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3979,
        "BEND_MAP_ID" : 3979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3978",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3978,
        "BEND_MAP_ID" : 3978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3977",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3977,
        "BEND_MAP_ID" : 3977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3976",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3976,
        "BEND_MAP_ID" : 3976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3975",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3975,
        "BEND_MAP_ID" : 3975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3974",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3974,
        "BEND_MAP_ID" : 3974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3973",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3973,
        "BEND_MAP_ID" : 3973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3972",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3972,
        "BEND_MAP_ID" : 3972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3971",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3971,
        "BEND_MAP_ID" : 3971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3970",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3970,
        "BEND_MAP_ID" : 3970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3969",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3969,
        "BEND_MAP_ID" : 3969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3968",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3968,
        "BEND_MAP_ID" : 3968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3967",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3967,
        "BEND_MAP_ID" : 3967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3966",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3966,
        "BEND_MAP_ID" : 3966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3965",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3965,
        "BEND_MAP_ID" : 3965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3964",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3964,
        "BEND_MAP_ID" : 3964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3963",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3963,
        "BEND_MAP_ID" : 3963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3962",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3962,
        "BEND_MAP_ID" : 3962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3961",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3961,
        "BEND_MAP_ID" : 3961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3960",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3960,
        "BEND_MAP_ID" : 3960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3959",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3959,
        "BEND_MAP_ID" : 3959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3958",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3958,
        "BEND_MAP_ID" : 3958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3957",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3957,
        "BEND_MAP_ID" : 3957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3956",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3956,
        "BEND_MAP_ID" : 3956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3955",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3955,
        "BEND_MAP_ID" : 3955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3954",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3954,
        "BEND_MAP_ID" : 3954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3953",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3953,
        "BEND_MAP_ID" : 3953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3952",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3952,
        "BEND_MAP_ID" : 3952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3951",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3951,
        "BEND_MAP_ID" : 3951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3950",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3950,
        "BEND_MAP_ID" : 3950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3949",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3949,
        "BEND_MAP_ID" : 3949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3948",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3948,
        "BEND_MAP_ID" : 3948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3947",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3947,
        "BEND_MAP_ID" : 3947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3946",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3946,
        "BEND_MAP_ID" : 3946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3945",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3945,
        "BEND_MAP_ID" : 3945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3944",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3944,
        "BEND_MAP_ID" : 3944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3943",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3943,
        "BEND_MAP_ID" : 3943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3942",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3942,
        "BEND_MAP_ID" : 3942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3941",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3941,
        "BEND_MAP_ID" : 3941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3940",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3940,
        "BEND_MAP_ID" : 3940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3939",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3939,
        "BEND_MAP_ID" : 3939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3938",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3938,
        "BEND_MAP_ID" : 3938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3937",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3937,
        "BEND_MAP_ID" : 3937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3936",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3936,
        "BEND_MAP_ID" : 3936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3935",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3935,
        "BEND_MAP_ID" : 3935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3934",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3934,
        "BEND_MAP_ID" : 3934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3933",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3933,
        "BEND_MAP_ID" : 3933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3932",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3932,
        "BEND_MAP_ID" : 3932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3931",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3931,
        "BEND_MAP_ID" : 3931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3930",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3930,
        "BEND_MAP_ID" : 3930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3929",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3929,
        "BEND_MAP_ID" : 3929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3928",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3928,
        "BEND_MAP_ID" : 3928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3927",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3927,
        "BEND_MAP_ID" : 3927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3926",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3926,
        "BEND_MAP_ID" : 3926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3925",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3925,
        "BEND_MAP_ID" : 3925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3924",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3924,
        "BEND_MAP_ID" : 3924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3923",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3923,
        "BEND_MAP_ID" : 3923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3922",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3922,
        "BEND_MAP_ID" : 3922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3921",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3921,
        "BEND_MAP_ID" : 3921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3920",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3920,
        "BEND_MAP_ID" : 3920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3919",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3919,
        "BEND_MAP_ID" : 3919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3918",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3918,
        "BEND_MAP_ID" : 3918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3917",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3917,
        "BEND_MAP_ID" : 3917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3916",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3916,
        "BEND_MAP_ID" : 3916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3915",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3915,
        "BEND_MAP_ID" : 3915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3914",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3914,
        "BEND_MAP_ID" : 3914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3913",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3913,
        "BEND_MAP_ID" : 3913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3912",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3912,
        "BEND_MAP_ID" : 3912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3911",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3911,
        "BEND_MAP_ID" : 3911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3910",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3910,
        "BEND_MAP_ID" : 3910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3909",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3909,
        "BEND_MAP_ID" : 3909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3908",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3908,
        "BEND_MAP_ID" : 3908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3907",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3907,
        "BEND_MAP_ID" : 3907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3906",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3906,
        "BEND_MAP_ID" : 3906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3905",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3905,
        "BEND_MAP_ID" : 3905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3904",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3904,
        "BEND_MAP_ID" : 3904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3903",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3903,
        "BEND_MAP_ID" : 3903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3902",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3902,
        "BEND_MAP_ID" : 3902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3901",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3901,
        "BEND_MAP_ID" : 3901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3900",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3900,
        "BEND_MAP_ID" : 3900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3899",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3899,
        "BEND_MAP_ID" : 3899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3898",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3898,
        "BEND_MAP_ID" : 3898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3897",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3897,
        "BEND_MAP_ID" : 3897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3896",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3896,
        "BEND_MAP_ID" : 3896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3895",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3895,
        "BEND_MAP_ID" : 3895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3894",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3894,
        "BEND_MAP_ID" : 3894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3893",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3893,
        "BEND_MAP_ID" : 3893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3892",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3892,
        "BEND_MAP_ID" : 3892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3891",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3891,
        "BEND_MAP_ID" : 3891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3890",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3890,
        "BEND_MAP_ID" : 3890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3889",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3889,
        "BEND_MAP_ID" : 3889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3888",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3888,
        "BEND_MAP_ID" : 3888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3887",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3887,
        "BEND_MAP_ID" : 3887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3886",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3886,
        "BEND_MAP_ID" : 3886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3885",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3885,
        "BEND_MAP_ID" : 3885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3884",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3884,
        "BEND_MAP_ID" : 3884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3883",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3883,
        "BEND_MAP_ID" : 3883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3882",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3882,
        "BEND_MAP_ID" : 3882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3881",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3881,
        "BEND_MAP_ID" : 3881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3880",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3880,
        "BEND_MAP_ID" : 3880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3879",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3879,
        "BEND_MAP_ID" : 3879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3878",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3878,
        "BEND_MAP_ID" : 3878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3877",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3877,
        "BEND_MAP_ID" : 3877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3876",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3876,
        "BEND_MAP_ID" : 3876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3875",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3875,
        "BEND_MAP_ID" : 3875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3874",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3874,
        "BEND_MAP_ID" : 3874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3873",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3873,
        "BEND_MAP_ID" : 3873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3872",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3872,
        "BEND_MAP_ID" : 3872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3871",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3871,
        "BEND_MAP_ID" : 3871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3870",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3870,
        "BEND_MAP_ID" : 3870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3869",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3869,
        "BEND_MAP_ID" : 3869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3868",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3868,
        "BEND_MAP_ID" : 3868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3867",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3867,
        "BEND_MAP_ID" : 3867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3866",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3866,
        "BEND_MAP_ID" : 3866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3865",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3865,
        "BEND_MAP_ID" : 3865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3864",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3864,
        "BEND_MAP_ID" : 3864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3863",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3863,
        "BEND_MAP_ID" : 3863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3862",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3862,
        "BEND_MAP_ID" : 3862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3861",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3861,
        "BEND_MAP_ID" : 3861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3860",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3860,
        "BEND_MAP_ID" : 3860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3859",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3859,
        "BEND_MAP_ID" : 3859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3858",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3858,
        "BEND_MAP_ID" : 3858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3857",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3857,
        "BEND_MAP_ID" : 3857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3856",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3856,
        "BEND_MAP_ID" : 3856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3855",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3855,
        "BEND_MAP_ID" : 3855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3854",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3854,
        "BEND_MAP_ID" : 3854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3853",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3853,
        "BEND_MAP_ID" : 3853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3852",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3852,
        "BEND_MAP_ID" : 3852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3851",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3851,
        "BEND_MAP_ID" : 3851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3850",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3850,
        "BEND_MAP_ID" : 3850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3849",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3849,
        "BEND_MAP_ID" : 3849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3848",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3848,
        "BEND_MAP_ID" : 3848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3847",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3847,
        "BEND_MAP_ID" : 3847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3846",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3846,
        "BEND_MAP_ID" : 3846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3845",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3845,
        "BEND_MAP_ID" : 3845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3844",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3844,
        "BEND_MAP_ID" : 3844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3843",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3843,
        "BEND_MAP_ID" : 3843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3842",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3842,
        "BEND_MAP_ID" : 3842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3841",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3841,
        "BEND_MAP_ID" : 3841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3840",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3840,
        "BEND_MAP_ID" : 3840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3839",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3839,
        "BEND_MAP_ID" : 3839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3838",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3838,
        "BEND_MAP_ID" : 3838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3837",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3837,
        "BEND_MAP_ID" : 3837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3836",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3836,
        "BEND_MAP_ID" : 3836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3835",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3835,
        "BEND_MAP_ID" : 3835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3834",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3834,
        "BEND_MAP_ID" : 3834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3833",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3833,
        "BEND_MAP_ID" : 3833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3832",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3832,
        "BEND_MAP_ID" : 3832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3831",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3831,
        "BEND_MAP_ID" : 3831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3830",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3830,
        "BEND_MAP_ID" : 3830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3829",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3829,
        "BEND_MAP_ID" : 3829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3828",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3828,
        "BEND_MAP_ID" : 3828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3827",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3827,
        "BEND_MAP_ID" : 3827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3826",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3826,
        "BEND_MAP_ID" : 3826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3825",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3825,
        "BEND_MAP_ID" : 3825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3824",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3824,
        "BEND_MAP_ID" : 3824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3823",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3823,
        "BEND_MAP_ID" : 3823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3822",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3822,
        "BEND_MAP_ID" : 3822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3821",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3821,
        "BEND_MAP_ID" : 3821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3820",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3820,
        "BEND_MAP_ID" : 3820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3819",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3819,
        "BEND_MAP_ID" : 3819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3818",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3818,
        "BEND_MAP_ID" : 3818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3817",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3817,
        "BEND_MAP_ID" : 3817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3816",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3816,
        "BEND_MAP_ID" : 3816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3815",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3815,
        "BEND_MAP_ID" : 3815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3814",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3814,
        "BEND_MAP_ID" : 3814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3813",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3813,
        "BEND_MAP_ID" : 3813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3812",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3812,
        "BEND_MAP_ID" : 3812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3811",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3811,
        "BEND_MAP_ID" : 3811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3810",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3810,
        "BEND_MAP_ID" : 3810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3809",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3809,
        "BEND_MAP_ID" : 3809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3808",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3808,
        "BEND_MAP_ID" : 3808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3807",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3807,
        "BEND_MAP_ID" : 3807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3806",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3806,
        "BEND_MAP_ID" : 3806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3805",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3805,
        "BEND_MAP_ID" : 3805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3804",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3804,
        "BEND_MAP_ID" : 3804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3803",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3803,
        "BEND_MAP_ID" : 3803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3802",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3802,
        "BEND_MAP_ID" : 3802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3801",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3801,
        "BEND_MAP_ID" : 3801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3800",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3800,
        "BEND_MAP_ID" : 3800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3799",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3799,
        "BEND_MAP_ID" : 3799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3798",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3798,
        "BEND_MAP_ID" : 3798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3797",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3797,
        "BEND_MAP_ID" : 3797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3796",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3796,
        "BEND_MAP_ID" : 3796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3795",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3795,
        "BEND_MAP_ID" : 3795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3794",
        "source" : "2915",
        "target" : "2894",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise 2)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3794,
        "BEND_MAP_ID" : 3794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3793",
        "source" : "2915",
        "target" : "2914",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead (Reprise)",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3793,
        "BEND_MAP_ID" : 3793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3792",
        "source" : "2915",
        "target" : "2913",
        "shared_name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) One Jump Ahead",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3792,
        "BEND_MAP_ID" : 3792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3791",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Mena Massoud) A Whole New World",
        "shared_interaction" : "Mena Massoud",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Mena Massoud) A Whole New World",
        "interaction" : "Mena Massoud",
        "voice_actor" : "voice actor",
        "SUID" : 3791,
        "BEND_MAP_ID" : 3791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3790",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3790,
        "BEND_MAP_ID" : 3790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3789",
        "source" : "2915",
        "target" : "2911",
        "shared_name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3789,
        "BEND_MAP_ID" : 3789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3788",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Lea Salonga) A Whole New World",
        "shared_interaction" : "Lea Salonga",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Lea Salonga) A Whole New World",
        "interaction" : "Lea Salonga",
        "voice_actor" : "voice actor",
        "SUID" : 3788,
        "BEND_MAP_ID" : 3788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3787",
        "source" : "2915",
        "target" : "2910",
        "shared_name" : "Alan Menken (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3787,
        "BEND_MAP_ID" : 3787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3786",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3786,
        "BEND_MAP_ID" : 3786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3785",
        "source" : "2915",
        "target" : "2912",
        "shared_name" : "Alan Menken (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3785,
        "BEND_MAP_ID" : 3785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3784",
        "source" : "2915",
        "target" : "2908",
        "shared_name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3784,
        "BEND_MAP_ID" : 3784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3783",
        "source" : "2915",
        "target" : "2907",
        "shared_name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3783,
        "BEND_MAP_ID" : 3783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3782",
        "source" : "2915",
        "target" : "2906",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3782,
        "BEND_MAP_ID" : 3782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3781",
        "source" : "2915",
        "target" : "2905",
        "shared_name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3781,
        "BEND_MAP_ID" : 3781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3780",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3780,
        "BEND_MAP_ID" : 3780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3779",
        "source" : "2915",
        "target" : "2903",
        "shared_name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3779,
        "BEND_MAP_ID" : 3779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3778",
        "source" : "2915",
        "target" : "2902",
        "shared_name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3778,
        "BEND_MAP_ID" : 3778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3777",
        "source" : "2915",
        "target" : "2901",
        "shared_name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3777,
        "BEND_MAP_ID" : 3777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3776",
        "source" : "2915",
        "target" : "2900",
        "shared_name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3776,
        "BEND_MAP_ID" : 3776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3775",
        "source" : "2915",
        "target" : "2909",
        "shared_name" : "Alan Menken (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3775,
        "BEND_MAP_ID" : 3775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3774",
        "source" : "2915",
        "target" : "2904",
        "shared_name" : "Alan Menken (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3774,
        "BEND_MAP_ID" : 3774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3773",
        "source" : "2915",
        "target" : "2899",
        "shared_name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3773,
        "BEND_MAP_ID" : 3773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3772",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3772,
        "BEND_MAP_ID" : 3772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3771",
        "source" : "2915",
        "target" : "2898",
        "shared_name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Alan Menken (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3771,
        "BEND_MAP_ID" : 3771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3770",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3770,
        "BEND_MAP_ID" : 3770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3769",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3769,
        "BEND_MAP_ID" : 3769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3768",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3768,
        "BEND_MAP_ID" : 3768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3767",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3767,
        "BEND_MAP_ID" : 3767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3766",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3766,
        "BEND_MAP_ID" : 3766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3765",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3765,
        "BEND_MAP_ID" : 3765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3764",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3764,
        "BEND_MAP_ID" : 3764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3763",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3763,
        "BEND_MAP_ID" : 3763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3762",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3762,
        "BEND_MAP_ID" : 3762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3761",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3761,
        "BEND_MAP_ID" : 3761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3760",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3760,
        "BEND_MAP_ID" : 3760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3759",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3759,
        "BEND_MAP_ID" : 3759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3758",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3758,
        "BEND_MAP_ID" : 3758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3757",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3757,
        "BEND_MAP_ID" : 3757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3756",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3756,
        "BEND_MAP_ID" : 3756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3755",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3755,
        "BEND_MAP_ID" : 3755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3754",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3754,
        "BEND_MAP_ID" : 3754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3753",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3753,
        "BEND_MAP_ID" : 3753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3752",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3752,
        "BEND_MAP_ID" : 3752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3751",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3751,
        "BEND_MAP_ID" : 3751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3750",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3750,
        "BEND_MAP_ID" : 3750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3749",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3749,
        "BEND_MAP_ID" : 3749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3748",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3748,
        "BEND_MAP_ID" : 3748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3747",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3747,
        "BEND_MAP_ID" : 3747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3746",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3746,
        "BEND_MAP_ID" : 3746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3745",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3745,
        "BEND_MAP_ID" : 3745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3744",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3744,
        "BEND_MAP_ID" : 3744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3743",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3743,
        "BEND_MAP_ID" : 3743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3742",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3742,
        "BEND_MAP_ID" : 3742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3741",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3741,
        "BEND_MAP_ID" : 3741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3740",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3740,
        "BEND_MAP_ID" : 3740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3739",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3739,
        "BEND_MAP_ID" : 3739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3738",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3738,
        "BEND_MAP_ID" : 3738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3737",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3737,
        "BEND_MAP_ID" : 3737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3736",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3736,
        "BEND_MAP_ID" : 3736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3735",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3735,
        "BEND_MAP_ID" : 3735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3734",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3734,
        "BEND_MAP_ID" : 3734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3733",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3733,
        "BEND_MAP_ID" : 3733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3732",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3732,
        "BEND_MAP_ID" : 3732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3731",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3731,
        "BEND_MAP_ID" : 3731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3730",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3730,
        "BEND_MAP_ID" : 3730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3729",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3729,
        "BEND_MAP_ID" : 3729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3728",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3728,
        "BEND_MAP_ID" : 3728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3727",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3727,
        "BEND_MAP_ID" : 3727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3726",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3726,
        "BEND_MAP_ID" : 3726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3725",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3725,
        "BEND_MAP_ID" : 3725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3724",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3724,
        "BEND_MAP_ID" : 3724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3723",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3723,
        "BEND_MAP_ID" : 3723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3722",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3722,
        "BEND_MAP_ID" : 3722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3721",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3721,
        "BEND_MAP_ID" : 3721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3720",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3720,
        "BEND_MAP_ID" : 3720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3719",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3719,
        "BEND_MAP_ID" : 3719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3718",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3718,
        "BEND_MAP_ID" : 3718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3717",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3717,
        "BEND_MAP_ID" : 3717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3716",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3716,
        "BEND_MAP_ID" : 3716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3715",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3715,
        "BEND_MAP_ID" : 3715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3714",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3714,
        "BEND_MAP_ID" : 3714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3713",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3713,
        "BEND_MAP_ID" : 3713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3712",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3712,
        "BEND_MAP_ID" : 3712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3711",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3711,
        "BEND_MAP_ID" : 3711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3710",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3710,
        "BEND_MAP_ID" : 3710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3709",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3709,
        "BEND_MAP_ID" : 3709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3708",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3708,
        "BEND_MAP_ID" : 3708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3707",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3707,
        "BEND_MAP_ID" : 3707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3706",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3706,
        "BEND_MAP_ID" : 3706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3705",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3705,
        "BEND_MAP_ID" : 3705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3704",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3704,
        "BEND_MAP_ID" : 3704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3703",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3703,
        "BEND_MAP_ID" : 3703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3702",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3702,
        "BEND_MAP_ID" : 3702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3701",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3701,
        "BEND_MAP_ID" : 3701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3700",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3700,
        "BEND_MAP_ID" : 3700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3699",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3699,
        "BEND_MAP_ID" : 3699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3698",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3698,
        "BEND_MAP_ID" : 3698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3697",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3697,
        "BEND_MAP_ID" : 3697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3696",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3696,
        "BEND_MAP_ID" : 3696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3695",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3695,
        "BEND_MAP_ID" : 3695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3694",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3694,
        "BEND_MAP_ID" : 3694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3693",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3693,
        "BEND_MAP_ID" : 3693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3692",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3692,
        "BEND_MAP_ID" : 3692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3691",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3691,
        "BEND_MAP_ID" : 3691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3690",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3690,
        "BEND_MAP_ID" : 3690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3689",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3689,
        "BEND_MAP_ID" : 3689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3688",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3688,
        "BEND_MAP_ID" : 3688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3687",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3687,
        "BEND_MAP_ID" : 3687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3686",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3686,
        "BEND_MAP_ID" : 3686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3685",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3685,
        "BEND_MAP_ID" : 3685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3684",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3684,
        "BEND_MAP_ID" : 3684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3683",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3683,
        "BEND_MAP_ID" : 3683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3682",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3682,
        "BEND_MAP_ID" : 3682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3681",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3681,
        "BEND_MAP_ID" : 3681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3680",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3680,
        "BEND_MAP_ID" : 3680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3679",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3679,
        "BEND_MAP_ID" : 3679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3678",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3678,
        "BEND_MAP_ID" : 3678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3677",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3677,
        "BEND_MAP_ID" : 3677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3676",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3676,
        "BEND_MAP_ID" : 3676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3675",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3675,
        "BEND_MAP_ID" : 3675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3674",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3674,
        "BEND_MAP_ID" : 3674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3673",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3673,
        "BEND_MAP_ID" : 3673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3672",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3672,
        "BEND_MAP_ID" : 3672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3671",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3671,
        "BEND_MAP_ID" : 3671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3670",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3670,
        "BEND_MAP_ID" : 3670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3669",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3669,
        "BEND_MAP_ID" : 3669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3668",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3668,
        "BEND_MAP_ID" : 3668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3667",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3667,
        "BEND_MAP_ID" : 3667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3666",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3666,
        "BEND_MAP_ID" : 3666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3665",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3665,
        "BEND_MAP_ID" : 3665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3664",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3664,
        "BEND_MAP_ID" : 3664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3663",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3663,
        "BEND_MAP_ID" : 3663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3662",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3662,
        "BEND_MAP_ID" : 3662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3661",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3661,
        "BEND_MAP_ID" : 3661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3660",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3660,
        "BEND_MAP_ID" : 3660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3659",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3659,
        "BEND_MAP_ID" : 3659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3658",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3658,
        "BEND_MAP_ID" : 3658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3657",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3657,
        "BEND_MAP_ID" : 3657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3656",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3656,
        "BEND_MAP_ID" : 3656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3655",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3655,
        "BEND_MAP_ID" : 3655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3654",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3654,
        "BEND_MAP_ID" : 3654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3653",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3653,
        "BEND_MAP_ID" : 3653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3652",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3652,
        "BEND_MAP_ID" : 3652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3651",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3651,
        "BEND_MAP_ID" : 3651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3650",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3650,
        "BEND_MAP_ID" : 3650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3649",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3649,
        "BEND_MAP_ID" : 3649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3648",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3648,
        "BEND_MAP_ID" : 3648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3647",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3647,
        "BEND_MAP_ID" : 3647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3646",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3646,
        "BEND_MAP_ID" : 3646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3645",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3645,
        "BEND_MAP_ID" : 3645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3644",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3644,
        "BEND_MAP_ID" : 3644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3643",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3643,
        "BEND_MAP_ID" : 3643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3642",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3642,
        "BEND_MAP_ID" : 3642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3641",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3641,
        "BEND_MAP_ID" : 3641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3640",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3640,
        "BEND_MAP_ID" : 3640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3639",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3639,
        "BEND_MAP_ID" : 3639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3638",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3638,
        "BEND_MAP_ID" : 3638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3637",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3637,
        "BEND_MAP_ID" : 3637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3636",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3636,
        "BEND_MAP_ID" : 3636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3635",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3635,
        "BEND_MAP_ID" : 3635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3634",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3634,
        "BEND_MAP_ID" : 3634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3633",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3633,
        "BEND_MAP_ID" : 3633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3632",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3632,
        "BEND_MAP_ID" : 3632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3631",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3631,
        "BEND_MAP_ID" : 3631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3630",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3630,
        "BEND_MAP_ID" : 3630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3629",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3629,
        "BEND_MAP_ID" : 3629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3628",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3628,
        "BEND_MAP_ID" : 3628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3627",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3627,
        "BEND_MAP_ID" : 3627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3626",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3626,
        "BEND_MAP_ID" : 3626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3625",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3625,
        "BEND_MAP_ID" : 3625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3624",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3624,
        "BEND_MAP_ID" : 3624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3623",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3623,
        "BEND_MAP_ID" : 3623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3622",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3622,
        "BEND_MAP_ID" : 3622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3621",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3621,
        "BEND_MAP_ID" : 3621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3620",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3620,
        "BEND_MAP_ID" : 3620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3619",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3619,
        "BEND_MAP_ID" : 3619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3618",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Will Smith) Prince Ali",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Prince Ali",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3618,
        "BEND_MAP_ID" : 3618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3617",
        "source" : "2897",
        "target" : "2903",
        "shared_name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Arabian Nights (2019)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3617,
        "BEND_MAP_ID" : 3617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3616",
        "source" : "2897",
        "target" : "2902",
        "shared_name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "shared_interaction" : "Will Smith",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Will Smith) Friend Like Me(Live Action)",
        "interaction" : "Will Smith",
        "voice_actor" : "voice actor",
        "SUID" : 3616,
        "BEND_MAP_ID" : 3616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3615",
        "source" : "2897",
        "target" : "2909",
        "shared_name" : "Howard Ashman (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3615,
        "BEND_MAP_ID" : 3615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3614",
        "source" : "2897",
        "target" : "2904",
        "shared_name" : "Howard Ashman (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3614,
        "BEND_MAP_ID" : 3614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3613",
        "source" : "2897",
        "target" : "2899",
        "shared_name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3613,
        "BEND_MAP_ID" : 3613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3612",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "shared_interaction" : "Brian Hannan",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Brian Hannan) Arabian Nights",
        "interaction" : "Brian Hannan",
        "voice_actor" : "voice actor",
        "SUID" : 3612,
        "BEND_MAP_ID" : 3612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3611",
        "source" : "2897",
        "target" : "2898",
        "shared_name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "shared_interaction" : "Bruce Adler",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Howard Ashman (Bruce Adler) Arabian Nights",
        "interaction" : "Bruce Adler",
        "voice_actor" : "voice actor",
        "SUID" : 3611,
        "BEND_MAP_ID" : 3611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3610",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3610,
        "BEND_MAP_ID" : 3610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3609",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3609,
        "BEND_MAP_ID" : 3609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3608",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3608,
        "BEND_MAP_ID" : 3608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3607",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3607,
        "BEND_MAP_ID" : 3607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3606",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3606,
        "BEND_MAP_ID" : 3606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3605",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3605,
        "BEND_MAP_ID" : 3605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3604",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3604,
        "BEND_MAP_ID" : 3604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3603",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3603,
        "BEND_MAP_ID" : 3603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3602",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3602,
        "BEND_MAP_ID" : 3602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3601",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3601,
        "BEND_MAP_ID" : 3601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3600",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3600,
        "BEND_MAP_ID" : 3600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3599",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3599,
        "BEND_MAP_ID" : 3599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3598",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3598,
        "BEND_MAP_ID" : 3598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3597",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3597,
        "BEND_MAP_ID" : 3597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3596",
        "source" : "2896",
        "target" : "2912",
        "shared_name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3596,
        "BEND_MAP_ID" : 3596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3595",
        "source" : "2896",
        "target" : "2911",
        "shared_name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Benj Pasek (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3595,
        "BEND_MAP_ID" : 3595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3594",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3594,
        "BEND_MAP_ID" : 3594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3593",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3593,
        "BEND_MAP_ID" : 3593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3592",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3592,
        "BEND_MAP_ID" : 3592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3591",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3591,
        "BEND_MAP_ID" : 3591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3590",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3590,
        "BEND_MAP_ID" : 3590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3589",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3589,
        "BEND_MAP_ID" : 3589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3588",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3588,
        "BEND_MAP_ID" : 3588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3587",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3587,
        "BEND_MAP_ID" : 3587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3586",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3586,
        "BEND_MAP_ID" : 3586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3585",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3585,
        "BEND_MAP_ID" : 3585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3584",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3584,
        "BEND_MAP_ID" : 3584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3583",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3583,
        "BEND_MAP_ID" : 3583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3582",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3582,
        "BEND_MAP_ID" : 3582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3581",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3581,
        "BEND_MAP_ID" : 3581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3580",
        "source" : "2895",
        "target" : "2912",
        "shared_name" : "Justin Paul (Naomi Scott) A Whole New World",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) A Whole New World",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3580,
        "BEND_MAP_ID" : 3580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3579",
        "source" : "2895",
        "target" : "2911",
        "shared_name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "shared_interaction" : "Naomi Scott",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin (Live-Action)",
        "name" : "Justin Paul (Naomi Scott) Speechless (Full-live)",
        "interaction" : "Naomi Scott",
        "voice_actor" : "voice actor",
        "SUID" : 3579,
        "BEND_MAP_ID" : 3579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3578",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3578,
        "BEND_MAP_ID" : 3578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3577",
        "source" : "2893",
        "target" : "2892",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3577,
        "BEND_MAP_ID" : 3577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3576",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3576,
        "BEND_MAP_ID" : 3576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3575",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3575,
        "BEND_MAP_ID" : 3575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3574",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3574,
        "BEND_MAP_ID" : 3574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3573",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3573,
        "BEND_MAP_ID" : 3573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3572",
        "source" : "2893",
        "target" : "2909",
        "shared_name" : "Patty Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3572,
        "BEND_MAP_ID" : 3572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3571",
        "source" : "2893",
        "target" : "2912",
        "shared_name" : "Patty Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3571,
        "BEND_MAP_ID" : 3571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3570",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3570,
        "BEND_MAP_ID" : 3570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3569",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3569,
        "BEND_MAP_ID" : 3569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3568",
        "source" : "2893",
        "target" : "2906",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3568,
        "BEND_MAP_ID" : 3568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3567",
        "source" : "2893",
        "target" : "2905",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3567,
        "BEND_MAP_ID" : 3567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3566",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3566,
        "BEND_MAP_ID" : 3566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3565",
        "source" : "2893",
        "target" : "2892",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3565,
        "BEND_MAP_ID" : 3565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3564",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3564,
        "BEND_MAP_ID" : 3564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3563",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3563,
        "BEND_MAP_ID" : 3563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3562",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3562,
        "BEND_MAP_ID" : 3562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3561",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3561,
        "BEND_MAP_ID" : 3561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3560",
        "source" : "2893",
        "target" : "2909",
        "shared_name" : "Patty Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3560,
        "BEND_MAP_ID" : 3560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3559",
        "source" : "2893",
        "target" : "2912",
        "shared_name" : "Patty Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3559,
        "BEND_MAP_ID" : 3559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3558",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3558,
        "BEND_MAP_ID" : 3558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3557",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3557,
        "BEND_MAP_ID" : 3557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3556",
        "source" : "2893",
        "target" : "2906",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3556,
        "BEND_MAP_ID" : 3556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3555",
        "source" : "2893",
        "target" : "2905",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3555,
        "BEND_MAP_ID" : 3555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3554",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3554,
        "BEND_MAP_ID" : 3554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3553",
        "source" : "2893",
        "target" : "2892",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3553,
        "BEND_MAP_ID" : 3553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3552",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3552,
        "BEND_MAP_ID" : 3552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3551",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3551,
        "BEND_MAP_ID" : 3551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3550",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3550,
        "BEND_MAP_ID" : 3550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3549",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3549,
        "BEND_MAP_ID" : 3549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3548",
        "source" : "2893",
        "target" : "2909",
        "shared_name" : "Patty Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3548,
        "BEND_MAP_ID" : 3548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3547",
        "source" : "2893",
        "target" : "2912",
        "shared_name" : "Patty Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3547,
        "BEND_MAP_ID" : 3547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3546",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3546,
        "BEND_MAP_ID" : 3546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3545",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3545,
        "BEND_MAP_ID" : 3545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3544",
        "source" : "2893",
        "target" : "2906",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3544,
        "BEND_MAP_ID" : 3544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3543",
        "source" : "2893",
        "target" : "2905",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3543,
        "BEND_MAP_ID" : 3543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3542",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3542,
        "BEND_MAP_ID" : 3542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3541",
        "source" : "2893",
        "target" : "2892",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3541,
        "BEND_MAP_ID" : 3541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3540",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3540,
        "BEND_MAP_ID" : 3540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3539",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3539,
        "BEND_MAP_ID" : 3539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3538",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3538,
        "BEND_MAP_ID" : 3538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3537",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3537,
        "BEND_MAP_ID" : 3537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3536",
        "source" : "2893",
        "target" : "2909",
        "shared_name" : "Patty Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3536,
        "BEND_MAP_ID" : 3536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3535",
        "source" : "2893",
        "target" : "2912",
        "shared_name" : "Patty Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3535,
        "BEND_MAP_ID" : 3535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3534",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3534,
        "BEND_MAP_ID" : 3534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3533",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3533,
        "BEND_MAP_ID" : 3533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3532",
        "source" : "2893",
        "target" : "2906",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3532,
        "BEND_MAP_ID" : 3532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3531",
        "source" : "2893",
        "target" : "2905",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3531,
        "BEND_MAP_ID" : 3531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3530",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3530,
        "BEND_MAP_ID" : 3530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3529",
        "source" : "2893",
        "target" : "2892",
        "shared_name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3529,
        "BEND_MAP_ID" : 3529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3528",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3528,
        "BEND_MAP_ID" : 3528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3527",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3527,
        "BEND_MAP_ID" : 3527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3526",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3526,
        "BEND_MAP_ID" : 3526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3525",
        "source" : "2893",
        "target" : "2910",
        "shared_name" : "Patty Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3525,
        "BEND_MAP_ID" : 3525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3524",
        "source" : "2893",
        "target" : "2909",
        "shared_name" : "Patty Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3524,
        "BEND_MAP_ID" : 3524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3523",
        "source" : "2893",
        "target" : "2912",
        "shared_name" : "Patty Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3523,
        "BEND_MAP_ID" : 3523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3522",
        "source" : "2893",
        "target" : "2908",
        "shared_name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3522,
        "BEND_MAP_ID" : 3522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3521",
        "source" : "2893",
        "target" : "2907",
        "shared_name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3521,
        "BEND_MAP_ID" : 3521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3520",
        "source" : "2893",
        "target" : "2906",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3520,
        "BEND_MAP_ID" : 3520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3519",
        "source" : "2893",
        "target" : "2905",
        "shared_name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Patty Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3519,
        "BEND_MAP_ID" : 3519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3518",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3518,
        "BEND_MAP_ID" : 3518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3517",
        "source" : "2891",
        "target" : "2892",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3517,
        "BEND_MAP_ID" : 3517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3516",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3516,
        "BEND_MAP_ID" : 3516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3515",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3515,
        "BEND_MAP_ID" : 3515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3514",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3514,
        "BEND_MAP_ID" : 3514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3513",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3513,
        "BEND_MAP_ID" : 3513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3512",
        "source" : "2891",
        "target" : "2909",
        "shared_name" : "Michael Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3512,
        "BEND_MAP_ID" : 3512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3511",
        "source" : "2891",
        "target" : "2912",
        "shared_name" : "Michael Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3511,
        "BEND_MAP_ID" : 3511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3510",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3510,
        "BEND_MAP_ID" : 3510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3509",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3509,
        "BEND_MAP_ID" : 3509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3508",
        "source" : "2891",
        "target" : "2906",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3508,
        "BEND_MAP_ID" : 3508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3507",
        "source" : "2891",
        "target" : "2905",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3507,
        "BEND_MAP_ID" : 3507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3506",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3506,
        "BEND_MAP_ID" : 3506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3505",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3505,
        "BEND_MAP_ID" : 3505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3504",
        "source" : "2891",
        "target" : "2892",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3504,
        "BEND_MAP_ID" : 3504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3503",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3503,
        "BEND_MAP_ID" : 3503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3502",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3502,
        "BEND_MAP_ID" : 3502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3501",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3501,
        "BEND_MAP_ID" : 3501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3500",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3500,
        "BEND_MAP_ID" : 3500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3499",
        "source" : "2891",
        "target" : "2909",
        "shared_name" : "Michael Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3499,
        "BEND_MAP_ID" : 3499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3498",
        "source" : "2891",
        "target" : "2912",
        "shared_name" : "Michael Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3498,
        "BEND_MAP_ID" : 3498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3497",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3497,
        "BEND_MAP_ID" : 3497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3496",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3496,
        "BEND_MAP_ID" : 3496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3495",
        "source" : "2891",
        "target" : "2906",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3495,
        "BEND_MAP_ID" : 3495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3494",
        "source" : "2891",
        "target" : "2905",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3494,
        "BEND_MAP_ID" : 3494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3493",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3493,
        "BEND_MAP_ID" : 3493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3492",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3492,
        "BEND_MAP_ID" : 3492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3491",
        "source" : "2891",
        "target" : "2892",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3491,
        "BEND_MAP_ID" : 3491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3490",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3490,
        "BEND_MAP_ID" : 3490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3489",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3489,
        "BEND_MAP_ID" : 3489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3488",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3488,
        "BEND_MAP_ID" : 3488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3487",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3487,
        "BEND_MAP_ID" : 3487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3486",
        "source" : "2891",
        "target" : "2909",
        "shared_name" : "Michael Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3486,
        "BEND_MAP_ID" : 3486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3485",
        "source" : "2891",
        "target" : "2912",
        "shared_name" : "Michael Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3485,
        "BEND_MAP_ID" : 3485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3484",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3484,
        "BEND_MAP_ID" : 3484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3483",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3483,
        "BEND_MAP_ID" : 3483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3482",
        "source" : "2891",
        "target" : "2906",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3482,
        "BEND_MAP_ID" : 3482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3481",
        "source" : "2891",
        "target" : "2905",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3481,
        "BEND_MAP_ID" : 3481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3480",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3480,
        "BEND_MAP_ID" : 3480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3479",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3479,
        "BEND_MAP_ID" : 3479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3478",
        "source" : "2891",
        "target" : "2892",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3478,
        "BEND_MAP_ID" : 3478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3477",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3477,
        "BEND_MAP_ID" : 3477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3476",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3476,
        "BEND_MAP_ID" : 3476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3475",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3475,
        "BEND_MAP_ID" : 3475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3474",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3474,
        "BEND_MAP_ID" : 3474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3473",
        "source" : "2891",
        "target" : "2909",
        "shared_name" : "Michael Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3473,
        "BEND_MAP_ID" : 3473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3472",
        "source" : "2891",
        "target" : "2912",
        "shared_name" : "Michael Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3472,
        "BEND_MAP_ID" : 3472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3471",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3471,
        "BEND_MAP_ID" : 3471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3470",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3470,
        "BEND_MAP_ID" : 3470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3469",
        "source" : "2891",
        "target" : "2906",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3469,
        "BEND_MAP_ID" : 3469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3468",
        "source" : "2891",
        "target" : "2905",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3468,
        "BEND_MAP_ID" : 3468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3467",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3467,
        "BEND_MAP_ID" : 3467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3466",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3466,
        "BEND_MAP_ID" : 3466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3465",
        "source" : "2891",
        "target" : "2892",
        "shared_name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3465,
        "BEND_MAP_ID" : 3465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3464",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3464,
        "BEND_MAP_ID" : 3464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3463",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3463,
        "BEND_MAP_ID" : 3463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3462",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3462,
        "BEND_MAP_ID" : 3462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3461",
        "source" : "2891",
        "target" : "2910",
        "shared_name" : "Michael Silversher (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3461,
        "BEND_MAP_ID" : 3461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3460",
        "source" : "2891",
        "target" : "2909",
        "shared_name" : "Michael Silversher (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3460,
        "BEND_MAP_ID" : 3460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3459",
        "source" : "2891",
        "target" : "2912",
        "shared_name" : "Michael Silversher (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3459,
        "BEND_MAP_ID" : 3459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3458",
        "source" : "2891",
        "target" : "2908",
        "shared_name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3458,
        "BEND_MAP_ID" : 3458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3457",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3457,
        "BEND_MAP_ID" : 3457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3456",
        "source" : "2891",
        "target" : "2906",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3456,
        "BEND_MAP_ID" : 3456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3455",
        "source" : "2891",
        "target" : "2905",
        "shared_name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3455,
        "BEND_MAP_ID" : 3455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3454",
        "source" : "2891",
        "target" : "2907",
        "shared_name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Michael Silversher (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3454,
        "BEND_MAP_ID" : 3454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3453",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3453,
        "BEND_MAP_ID" : 3453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3452",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3452,
        "BEND_MAP_ID" : 3452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3451",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3451,
        "BEND_MAP_ID" : 3451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3450",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3450,
        "BEND_MAP_ID" : 3450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3449",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3449,
        "BEND_MAP_ID" : 3449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3448",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3448,
        "BEND_MAP_ID" : 3448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3447",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3447,
        "BEND_MAP_ID" : 3447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3446",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3446,
        "BEND_MAP_ID" : 3446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3445,
        "BEND_MAP_ID" : 3445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3444",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3444,
        "BEND_MAP_ID" : 3444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3443",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3443,
        "BEND_MAP_ID" : 3443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3442",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3442,
        "BEND_MAP_ID" : 3442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3441",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3441,
        "BEND_MAP_ID" : 3441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3440",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3440,
        "BEND_MAP_ID" : 3440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3439",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3439,
        "BEND_MAP_ID" : 3439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3438",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3438,
        "BEND_MAP_ID" : 3438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3437",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3437,
        "BEND_MAP_ID" : 3437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3436",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3436,
        "BEND_MAP_ID" : 3436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3435",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3435,
        "BEND_MAP_ID" : 3435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3434",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3434,
        "BEND_MAP_ID" : 3434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3433",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3433,
        "BEND_MAP_ID" : 3433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3432",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3432,
        "BEND_MAP_ID" : 3432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3431",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3431,
        "BEND_MAP_ID" : 3431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3430",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3430,
        "BEND_MAP_ID" : 3430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3429",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3429,
        "BEND_MAP_ID" : 3429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3428",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3428,
        "BEND_MAP_ID" : 3428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3427",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3427,
        "BEND_MAP_ID" : 3427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3426",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3426,
        "BEND_MAP_ID" : 3426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3425",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3425,
        "BEND_MAP_ID" : 3425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3424",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3424,
        "BEND_MAP_ID" : 3424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3423",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3423,
        "BEND_MAP_ID" : 3423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3422",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3422,
        "BEND_MAP_ID" : 3422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3421",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3421,
        "BEND_MAP_ID" : 3421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3420",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3420,
        "BEND_MAP_ID" : 3420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3419",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3419,
        "BEND_MAP_ID" : 3419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3418",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3418,
        "BEND_MAP_ID" : 3418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3417",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3417,
        "BEND_MAP_ID" : 3417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3416",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3416,
        "BEND_MAP_ID" : 3416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3415",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3415,
        "BEND_MAP_ID" : 3415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3414",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3414,
        "BEND_MAP_ID" : 3414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3413",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3413,
        "BEND_MAP_ID" : 3413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3412",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3412,
        "BEND_MAP_ID" : 3412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3411",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3411,
        "BEND_MAP_ID" : 3411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3410",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3410,
        "BEND_MAP_ID" : 3410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3409",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3409,
        "BEND_MAP_ID" : 3409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3408",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3408,
        "BEND_MAP_ID" : 3408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3407",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3407,
        "BEND_MAP_ID" : 3407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3406",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3406,
        "BEND_MAP_ID" : 3406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3405,
        "BEND_MAP_ID" : 3405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3404",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3404,
        "BEND_MAP_ID" : 3404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3403",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3403,
        "BEND_MAP_ID" : 3403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3402",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3402,
        "BEND_MAP_ID" : 3402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3401",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3401,
        "BEND_MAP_ID" : 3401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3400",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3400,
        "BEND_MAP_ID" : 3400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3399",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3399,
        "BEND_MAP_ID" : 3399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3398",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3398,
        "BEND_MAP_ID" : 3398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3397",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3397,
        "BEND_MAP_ID" : 3397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3396",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3396,
        "BEND_MAP_ID" : 3396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3395",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3395,
        "BEND_MAP_ID" : 3395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3394",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3394,
        "BEND_MAP_ID" : 3394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3393",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3393,
        "BEND_MAP_ID" : 3393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3392",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3392,
        "BEND_MAP_ID" : 3392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3391",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3391,
        "BEND_MAP_ID" : 3391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3390",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3390,
        "BEND_MAP_ID" : 3390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3389",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3389,
        "BEND_MAP_ID" : 3389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3388",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3388,
        "BEND_MAP_ID" : 3388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3387",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3387,
        "BEND_MAP_ID" : 3387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3386",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3386,
        "BEND_MAP_ID" : 3386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3385",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3385,
        "BEND_MAP_ID" : 3385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3384",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3384,
        "BEND_MAP_ID" : 3384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3383",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3383,
        "BEND_MAP_ID" : 3383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3382",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3382,
        "BEND_MAP_ID" : 3382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3381",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3381,
        "BEND_MAP_ID" : 3381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3380",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3380,
        "BEND_MAP_ID" : 3380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3379",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3379,
        "BEND_MAP_ID" : 3379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3378",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3378,
        "BEND_MAP_ID" : 3378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3377",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3377,
        "BEND_MAP_ID" : 3377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3376",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3376,
        "BEND_MAP_ID" : 3376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3375",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3375,
        "BEND_MAP_ID" : 3375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3374",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3374,
        "BEND_MAP_ID" : 3374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3373",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3373,
        "BEND_MAP_ID" : 3373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3372",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3372,
        "BEND_MAP_ID" : 3372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3371",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3371,
        "BEND_MAP_ID" : 3371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3370",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3370,
        "BEND_MAP_ID" : 3370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3369",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3369,
        "BEND_MAP_ID" : 3369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3368",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3368,
        "BEND_MAP_ID" : 3368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3367",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3367,
        "BEND_MAP_ID" : 3367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3366",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3366,
        "BEND_MAP_ID" : 3366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3365",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3365,
        "BEND_MAP_ID" : 3365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3364",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3364,
        "BEND_MAP_ID" : 3364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3363",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3363,
        "BEND_MAP_ID" : 3363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3362",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3362,
        "BEND_MAP_ID" : 3362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3361",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3361,
        "BEND_MAP_ID" : 3361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3360",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3360,
        "BEND_MAP_ID" : 3360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3359",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3359,
        "BEND_MAP_ID" : 3359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3358",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3358,
        "BEND_MAP_ID" : 3358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3357",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3357,
        "BEND_MAP_ID" : 3357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3356",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3356,
        "BEND_MAP_ID" : 3356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3355",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3355,
        "BEND_MAP_ID" : 3355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3354",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3354,
        "BEND_MAP_ID" : 3354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3353",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3353,
        "BEND_MAP_ID" : 3353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3352",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3352,
        "BEND_MAP_ID" : 3352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3351",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3351,
        "BEND_MAP_ID" : 3351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3350",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3350,
        "BEND_MAP_ID" : 3350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3349",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3349,
        "BEND_MAP_ID" : 3349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3348",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3348,
        "BEND_MAP_ID" : 3348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3347",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3347,
        "BEND_MAP_ID" : 3347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3346",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3346,
        "BEND_MAP_ID" : 3346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3345",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3345,
        "BEND_MAP_ID" : 3345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3344",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3344,
        "BEND_MAP_ID" : 3344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3343,
        "BEND_MAP_ID" : 3343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3342",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3342,
        "BEND_MAP_ID" : 3342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3341",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3341,
        "BEND_MAP_ID" : 3341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3340",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3340,
        "BEND_MAP_ID" : 3340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3339",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3339,
        "BEND_MAP_ID" : 3339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3338",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3338,
        "BEND_MAP_ID" : 3338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3337",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3337,
        "BEND_MAP_ID" : 3337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3336",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3336,
        "BEND_MAP_ID" : 3336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3335",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3335,
        "BEND_MAP_ID" : 3335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3334",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3334,
        "BEND_MAP_ID" : 3334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3333",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3333,
        "BEND_MAP_ID" : 3333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3332",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3332,
        "BEND_MAP_ID" : 3332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3331",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3331,
        "BEND_MAP_ID" : 3331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3330",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3330,
        "BEND_MAP_ID" : 3330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3329",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3329,
        "BEND_MAP_ID" : 3329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3328",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3328,
        "BEND_MAP_ID" : 3328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3327",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3327,
        "BEND_MAP_ID" : 3327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3326",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3326,
        "BEND_MAP_ID" : 3326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3325",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3325,
        "BEND_MAP_ID" : 3325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3324",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3324,
        "BEND_MAP_ID" : 3324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3323",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3323,
        "BEND_MAP_ID" : 3323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3322",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3322,
        "BEND_MAP_ID" : 3322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3321",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3321,
        "BEND_MAP_ID" : 3321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3320",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3320,
        "BEND_MAP_ID" : 3320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3319",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3319,
        "BEND_MAP_ID" : 3319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3318",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3318,
        "BEND_MAP_ID" : 3318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3317",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3317,
        "BEND_MAP_ID" : 3317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3316",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3316,
        "BEND_MAP_ID" : 3316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3315",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3315,
        "BEND_MAP_ID" : 3315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3314",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3314,
        "BEND_MAP_ID" : 3314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3313",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3313,
        "BEND_MAP_ID" : 3313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3312",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3312,
        "BEND_MAP_ID" : 3312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3311",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3311,
        "BEND_MAP_ID" : 3311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3310",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3310,
        "BEND_MAP_ID" : 3310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3309",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3309,
        "BEND_MAP_ID" : 3309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3308",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3308,
        "BEND_MAP_ID" : 3308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3307",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3307,
        "BEND_MAP_ID" : 3307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3306",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3306,
        "BEND_MAP_ID" : 3306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3305",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3305,
        "BEND_MAP_ID" : 3305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3304",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3304,
        "BEND_MAP_ID" : 3304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3303",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3303,
        "BEND_MAP_ID" : 3303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3302",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3302,
        "BEND_MAP_ID" : 3302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3301",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3301,
        "BEND_MAP_ID" : 3301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3300",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3300,
        "BEND_MAP_ID" : 3300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3299",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3299,
        "BEND_MAP_ID" : 3299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3298",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3298,
        "BEND_MAP_ID" : 3298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3297",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3297,
        "BEND_MAP_ID" : 3297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3296",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3296,
        "BEND_MAP_ID" : 3296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3295",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3295,
        "BEND_MAP_ID" : 3295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3294",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3294,
        "BEND_MAP_ID" : 3294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3293",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3293,
        "BEND_MAP_ID" : 3293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3292",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3292,
        "BEND_MAP_ID" : 3292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3291",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3291,
        "BEND_MAP_ID" : 3291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3290",
        "source" : "2890",
        "target" : "2904",
        "shared_name" : "Randy Petersen (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3290,
        "BEND_MAP_ID" : 3290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3289",
        "source" : "2890",
        "target" : "2899",
        "shared_name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3289,
        "BEND_MAP_ID" : 3289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3288",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3288,
        "BEND_MAP_ID" : 3288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3287",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3287,
        "BEND_MAP_ID" : 3287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3286",
        "source" : "2890",
        "target" : "2912",
        "shared_name" : "Randy Petersen (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3286,
        "BEND_MAP_ID" : 3286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3285",
        "source" : "2890",
        "target" : "2908",
        "shared_name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3285,
        "BEND_MAP_ID" : 3285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3284",
        "source" : "2890",
        "target" : "2907",
        "shared_name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3284,
        "BEND_MAP_ID" : 3284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3283",
        "source" : "2890",
        "target" : "2906",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3283,
        "BEND_MAP_ID" : 3283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3282",
        "source" : "2890",
        "target" : "2905",
        "shared_name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3282,
        "BEND_MAP_ID" : 3282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3281",
        "source" : "2890",
        "target" : "2909",
        "shared_name" : "Randy Petersen (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3281,
        "BEND_MAP_ID" : 3281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3280",
        "source" : "2890",
        "target" : "2889",
        "shared_name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3280,
        "BEND_MAP_ID" : 3280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "2890",
        "target" : "2888",
        "shared_name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3279,
        "BEND_MAP_ID" : 3279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3278",
        "source" : "2890",
        "target" : "2887",
        "shared_name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3278,
        "BEND_MAP_ID" : 3278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3277",
        "source" : "2890",
        "target" : "2910",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3277,
        "BEND_MAP_ID" : 3277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3276",
        "source" : "2890",
        "target" : "2892",
        "shared_name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3276,
        "BEND_MAP_ID" : 3276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3275",
        "source" : "2890",
        "target" : "2901",
        "shared_name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3275,
        "BEND_MAP_ID" : 3275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3274",
        "source" : "2890",
        "target" : "2900",
        "shared_name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Randy Petersen (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3274,
        "BEND_MAP_ID" : 3274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3273",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3273,
        "BEND_MAP_ID" : 3273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3272",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3272,
        "BEND_MAP_ID" : 3272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3271",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3271,
        "BEND_MAP_ID" : 3271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3270",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3270,
        "BEND_MAP_ID" : 3270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3269",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3269,
        "BEND_MAP_ID" : 3269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3268",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3268,
        "BEND_MAP_ID" : 3268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3267",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3267,
        "BEND_MAP_ID" : 3267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3266",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3266,
        "BEND_MAP_ID" : 3266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3265",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3265,
        "BEND_MAP_ID" : 3265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3264",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3264,
        "BEND_MAP_ID" : 3264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3263",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3263,
        "BEND_MAP_ID" : 3263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3262",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3262,
        "BEND_MAP_ID" : 3262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3261",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3261,
        "BEND_MAP_ID" : 3261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3260",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3260,
        "BEND_MAP_ID" : 3260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3259",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3259,
        "BEND_MAP_ID" : 3259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3258",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3258,
        "BEND_MAP_ID" : 3258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3257",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3257,
        "BEND_MAP_ID" : 3257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3256",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3256,
        "BEND_MAP_ID" : 3256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3255",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3255,
        "BEND_MAP_ID" : 3255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3254",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3254,
        "BEND_MAP_ID" : 3254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3253",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3253,
        "BEND_MAP_ID" : 3253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3252",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3252,
        "BEND_MAP_ID" : 3252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3251",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3251,
        "BEND_MAP_ID" : 3251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3250",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3250,
        "BEND_MAP_ID" : 3250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3249",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3249,
        "BEND_MAP_ID" : 3249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3248",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3248,
        "BEND_MAP_ID" : 3248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3247",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3247,
        "BEND_MAP_ID" : 3247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3246",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3246,
        "BEND_MAP_ID" : 3246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3245",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3245,
        "BEND_MAP_ID" : 3245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3244",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3244,
        "BEND_MAP_ID" : 3244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3243",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3243,
        "BEND_MAP_ID" : 3243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3242",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3242,
        "BEND_MAP_ID" : 3242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3241",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3241,
        "BEND_MAP_ID" : 3241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3240",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3240,
        "BEND_MAP_ID" : 3240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3239,
        "BEND_MAP_ID" : 3239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3238",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3238,
        "BEND_MAP_ID" : 3238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3237",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3237,
        "BEND_MAP_ID" : 3237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3236",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3236,
        "BEND_MAP_ID" : 3236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3235",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3235,
        "BEND_MAP_ID" : 3235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3234",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3234,
        "BEND_MAP_ID" : 3234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3233",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3233,
        "BEND_MAP_ID" : 3233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3232",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3232,
        "BEND_MAP_ID" : 3232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3231",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3231,
        "BEND_MAP_ID" : 3231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3230",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3230,
        "BEND_MAP_ID" : 3230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3229",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3229,
        "BEND_MAP_ID" : 3229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3228",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3228,
        "BEND_MAP_ID" : 3228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3227",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3227,
        "BEND_MAP_ID" : 3227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3226",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3226,
        "BEND_MAP_ID" : 3226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3225",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3225,
        "BEND_MAP_ID" : 3225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3224",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3224,
        "BEND_MAP_ID" : 3224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3223",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3223,
        "BEND_MAP_ID" : 3223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3222",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3222,
        "BEND_MAP_ID" : 3222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3221",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3221,
        "BEND_MAP_ID" : 3221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3220",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3220,
        "BEND_MAP_ID" : 3220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3219",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3219,
        "BEND_MAP_ID" : 3219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3218",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3218,
        "BEND_MAP_ID" : 3218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3217",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3217,
        "BEND_MAP_ID" : 3217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3216",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3216,
        "BEND_MAP_ID" : 3216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3215",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3215,
        "BEND_MAP_ID" : 3215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3214",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3214,
        "BEND_MAP_ID" : 3214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3213",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3213,
        "BEND_MAP_ID" : 3213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3212",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3212,
        "BEND_MAP_ID" : 3212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3211,
        "BEND_MAP_ID" : 3211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3210",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3210,
        "BEND_MAP_ID" : 3210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3209",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3209,
        "BEND_MAP_ID" : 3209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3208",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3208,
        "BEND_MAP_ID" : 3208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3207",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3207,
        "BEND_MAP_ID" : 3207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3206",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3206,
        "BEND_MAP_ID" : 3206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3205",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3205,
        "BEND_MAP_ID" : 3205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3204",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3204,
        "BEND_MAP_ID" : 3204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3203",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3203,
        "BEND_MAP_ID" : 3203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3202",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3202,
        "BEND_MAP_ID" : 3202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3201",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3201,
        "BEND_MAP_ID" : 3201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3200",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3200,
        "BEND_MAP_ID" : 3200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3199",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3199,
        "BEND_MAP_ID" : 3199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3198",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3198,
        "BEND_MAP_ID" : 3198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3197",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3197,
        "BEND_MAP_ID" : 3197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3196",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3196,
        "BEND_MAP_ID" : 3196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3195",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3195,
        "BEND_MAP_ID" : 3195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3194",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3194,
        "BEND_MAP_ID" : 3194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3193",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3193,
        "BEND_MAP_ID" : 3193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3192",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3192,
        "BEND_MAP_ID" : 3192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3191",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3191,
        "BEND_MAP_ID" : 3191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3190",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3190,
        "BEND_MAP_ID" : 3190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3189",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3189,
        "BEND_MAP_ID" : 3189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3188",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3188,
        "BEND_MAP_ID" : 3188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3187",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3187,
        "BEND_MAP_ID" : 3187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3186",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3186,
        "BEND_MAP_ID" : 3186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3185",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3185,
        "BEND_MAP_ID" : 3185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3184",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3184,
        "BEND_MAP_ID" : 3184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3183",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3183,
        "BEND_MAP_ID" : 3183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3182",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3182,
        "BEND_MAP_ID" : 3182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3181",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3181,
        "BEND_MAP_ID" : 3181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3180",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3180,
        "BEND_MAP_ID" : 3180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3179",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3179,
        "BEND_MAP_ID" : 3179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3178",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3178,
        "BEND_MAP_ID" : 3178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3177",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3177,
        "BEND_MAP_ID" : 3177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3176",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3176,
        "BEND_MAP_ID" : 3176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3175",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3175,
        "BEND_MAP_ID" : 3175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3174",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3174,
        "BEND_MAP_ID" : 3174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3173",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3173,
        "BEND_MAP_ID" : 3173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3172",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3172,
        "BEND_MAP_ID" : 3172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3171",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3171,
        "BEND_MAP_ID" : 3171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3170",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3170,
        "BEND_MAP_ID" : 3170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3169",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3169,
        "BEND_MAP_ID" : 3169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3168",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3168,
        "BEND_MAP_ID" : 3168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3167",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3167,
        "BEND_MAP_ID" : 3167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3166",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3166,
        "BEND_MAP_ID" : 3166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3165",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3165,
        "BEND_MAP_ID" : 3165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3164",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3164,
        "BEND_MAP_ID" : 3164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3163",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3163,
        "BEND_MAP_ID" : 3163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3162",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3162,
        "BEND_MAP_ID" : 3162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3161",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3161,
        "BEND_MAP_ID" : 3161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3160",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3160,
        "BEND_MAP_ID" : 3160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3159",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3159,
        "BEND_MAP_ID" : 3159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3158",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3158,
        "BEND_MAP_ID" : 3158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3157",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3157,
        "BEND_MAP_ID" : 3157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3156",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3156,
        "BEND_MAP_ID" : 3156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3155",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3155,
        "BEND_MAP_ID" : 3155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3154",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3154,
        "BEND_MAP_ID" : 3154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3153",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3153,
        "BEND_MAP_ID" : 3153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3152",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3152,
        "BEND_MAP_ID" : 3152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3151",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3151,
        "BEND_MAP_ID" : 3151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3150",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3150,
        "BEND_MAP_ID" : 3150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3149,
        "BEND_MAP_ID" : 3149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3148",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3148,
        "BEND_MAP_ID" : 3148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3147",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3147,
        "BEND_MAP_ID" : 3147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3146",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3146,
        "BEND_MAP_ID" : 3146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3145",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3145,
        "BEND_MAP_ID" : 3145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3144",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3144,
        "BEND_MAP_ID" : 3144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3143",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3143,
        "BEND_MAP_ID" : 3143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3142",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3142,
        "BEND_MAP_ID" : 3142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3141",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3141,
        "BEND_MAP_ID" : 3141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3140",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3140,
        "BEND_MAP_ID" : 3140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3139",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3139,
        "BEND_MAP_ID" : 3139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3138",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3138,
        "BEND_MAP_ID" : 3138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3137",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3137,
        "BEND_MAP_ID" : 3137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3136",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3136,
        "BEND_MAP_ID" : 3136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3135",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3135,
        "BEND_MAP_ID" : 3135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3134",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3134,
        "BEND_MAP_ID" : 3134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3133",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3133,
        "BEND_MAP_ID" : 3133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3132",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3132,
        "BEND_MAP_ID" : 3132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3131",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3131,
        "BEND_MAP_ID" : 3131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3130",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3130,
        "BEND_MAP_ID" : 3130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3129",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3129,
        "BEND_MAP_ID" : 3129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3128",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3128,
        "BEND_MAP_ID" : 3128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3127",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3127,
        "BEND_MAP_ID" : 3127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3126",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3126,
        "BEND_MAP_ID" : 3126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3125",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3125,
        "BEND_MAP_ID" : 3125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3124",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3124,
        "BEND_MAP_ID" : 3124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3123",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3123,
        "BEND_MAP_ID" : 3123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3122",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3122,
        "BEND_MAP_ID" : 3122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3121",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3121,
        "BEND_MAP_ID" : 3121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3120",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3120,
        "BEND_MAP_ID" : 3120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3119",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3119,
        "BEND_MAP_ID" : 3119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3118",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3118,
        "BEND_MAP_ID" : 3118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3117",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3117,
        "BEND_MAP_ID" : 3117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3116",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3116,
        "BEND_MAP_ID" : 3116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3115",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3115,
        "BEND_MAP_ID" : 3115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3114",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3114,
        "BEND_MAP_ID" : 3114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3113",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3113,
        "BEND_MAP_ID" : 3113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3112",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3112,
        "BEND_MAP_ID" : 3112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3111",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Robin Williams) Father and Son",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Father and Son",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3111,
        "BEND_MAP_ID" : 3111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3110",
        "source" : "2886",
        "target" : "2904",
        "shared_name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Prince Ali",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3110,
        "BEND_MAP_ID" : 3110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3109",
        "source" : "2886",
        "target" : "2899",
        "shared_name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "shared_interaction" : "Robin Williams",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Robin Williams) Friend Like Me(Animated)",
        "interaction" : "Robin Williams",
        "voice_actor" : "voice actor",
        "SUID" : 3109,
        "BEND_MAP_ID" : 3109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3108",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3108,
        "BEND_MAP_ID" : 3108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3107",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3107,
        "BEND_MAP_ID" : 3107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3106",
        "source" : "2886",
        "target" : "2912",
        "shared_name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3106,
        "BEND_MAP_ID" : 3106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3105",
        "source" : "2886",
        "target" : "2908",
        "shared_name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3105,
        "BEND_MAP_ID" : 3105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3104",
        "source" : "2886",
        "target" : "2907",
        "shared_name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3104,
        "BEND_MAP_ID" : 3104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3103",
        "source" : "2886",
        "target" : "2906",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3103,
        "BEND_MAP_ID" : 3103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3102",
        "source" : "2886",
        "target" : "2905",
        "shared_name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3102,
        "BEND_MAP_ID" : 3102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3101",
        "source" : "2886",
        "target" : "2909",
        "shared_name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "shared_interaction" : "Merwin Foard",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Merwin Foard) Father and Son",
        "interaction" : "Merwin Foard",
        "voice_actor" : "voice actor",
        "SUID" : 3101,
        "BEND_MAP_ID" : 3101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3100",
        "source" : "2886",
        "target" : "2889",
        "shared_name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "shared_interaction" : "Jerry Orbach",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jerry Orbach) Are You in or Out?",
        "interaction" : "Jerry Orbach",
        "voice_actor" : "voice actor",
        "SUID" : 3100,
        "BEND_MAP_ID" : 3100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3099",
        "source" : "2886",
        "target" : "2888",
        "shared_name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3099,
        "BEND_MAP_ID" : 3099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3098",
        "source" : "2886",
        "target" : "2887",
        "shared_name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3098,
        "BEND_MAP_ID" : 3098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3097",
        "source" : "2886",
        "target" : "2910",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) Forget About Love",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3097,
        "BEND_MAP_ID" : 3097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3096",
        "source" : "2886",
        "target" : "2892",
        "shared_name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "shared_interaction" : "Gilbert Gottfried",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Gilbert Gottfried) I'm Looking Out For Me(1994)",
        "interaction" : "Gilbert Gottfried",
        "voice_actor" : "voice actor",
        "SUID" : 3096,
        "BEND_MAP_ID" : 3096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3095",
        "source" : "2886",
        "target" : "2901",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3095,
        "BEND_MAP_ID" : 3095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3094",
        "source" : "2886",
        "target" : "2900",
        "shared_name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Kevin Quinn (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 3094,
        "BEND_MAP_ID" : 3094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3093",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3093,
        "BEND_MAP_ID" : 3093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3092",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3092,
        "BEND_MAP_ID" : 3092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3091",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3091,
        "BEND_MAP_ID" : 3091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3090",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3090,
        "BEND_MAP_ID" : 3090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3089",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3089,
        "BEND_MAP_ID" : 3089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3088",
        "source" : "2885",
        "target" : "2909",
        "shared_name" : "Dale Gonyea (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3088,
        "BEND_MAP_ID" : 3088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3087",
        "source" : "2885",
        "target" : "2912",
        "shared_name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3087,
        "BEND_MAP_ID" : 3087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3086",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3086,
        "BEND_MAP_ID" : 3086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3085",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3085,
        "BEND_MAP_ID" : 3085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3084",
        "source" : "2885",
        "target" : "2906",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3084,
        "BEND_MAP_ID" : 3084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3083",
        "source" : "2885",
        "target" : "2905",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3083,
        "BEND_MAP_ID" : 3083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3082",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3082,
        "BEND_MAP_ID" : 3082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3081",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3081,
        "BEND_MAP_ID" : 3081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3080",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3080,
        "BEND_MAP_ID" : 3080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3079",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3079,
        "BEND_MAP_ID" : 3079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3078",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3078,
        "BEND_MAP_ID" : 3078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3077",
        "source" : "2885",
        "target" : "2909",
        "shared_name" : "Dale Gonyea (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3077,
        "BEND_MAP_ID" : 3077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3076",
        "source" : "2885",
        "target" : "2912",
        "shared_name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3076,
        "BEND_MAP_ID" : 3076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3075",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3075,
        "BEND_MAP_ID" : 3075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3074",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3074,
        "BEND_MAP_ID" : 3074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3073",
        "source" : "2885",
        "target" : "2906",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3073,
        "BEND_MAP_ID" : 3073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3072",
        "source" : "2885",
        "target" : "2905",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3072,
        "BEND_MAP_ID" : 3072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3071",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3071,
        "BEND_MAP_ID" : 3071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3070",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3070,
        "BEND_MAP_ID" : 3070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3069",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3069,
        "BEND_MAP_ID" : 3069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3068",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3068,
        "BEND_MAP_ID" : 3068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3067",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3067,
        "BEND_MAP_ID" : 3067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3066",
        "source" : "2885",
        "target" : "2909",
        "shared_name" : "Dale Gonyea (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3066,
        "BEND_MAP_ID" : 3066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3065",
        "source" : "2885",
        "target" : "2912",
        "shared_name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3065,
        "BEND_MAP_ID" : 3065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3064",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3064,
        "BEND_MAP_ID" : 3064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3063",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3063,
        "BEND_MAP_ID" : 3063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3062",
        "source" : "2885",
        "target" : "2906",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3062,
        "BEND_MAP_ID" : 3062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3061",
        "source" : "2885",
        "target" : "2905",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3061,
        "BEND_MAP_ID" : 3061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3060",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3060,
        "BEND_MAP_ID" : 3060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3059",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3059,
        "BEND_MAP_ID" : 3059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3058",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3058,
        "BEND_MAP_ID" : 3058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3057",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3057,
        "BEND_MAP_ID" : 3057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3056",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3056,
        "BEND_MAP_ID" : 3056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3055",
        "source" : "2885",
        "target" : "2909",
        "shared_name" : "Dale Gonyea (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3055,
        "BEND_MAP_ID" : 3055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3054",
        "source" : "2885",
        "target" : "2912",
        "shared_name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3054,
        "BEND_MAP_ID" : 3054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3053",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3053,
        "BEND_MAP_ID" : 3053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3052",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3052,
        "BEND_MAP_ID" : 3052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3051",
        "source" : "2885",
        "target" : "2906",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3051,
        "BEND_MAP_ID" : 3051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3050",
        "source" : "2885",
        "target" : "2905",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3050,
        "BEND_MAP_ID" : 3050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3049",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3049,
        "BEND_MAP_ID" : 3049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3048",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3048,
        "BEND_MAP_ID" : 3048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3047",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3047,
        "BEND_MAP_ID" : 3047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3046",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Dan Castellaneta",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Dan Castellaneta) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Dan Castellaneta",
        "voice_actor" : "voice actor",
        "SUID" : 3046,
        "BEND_MAP_ID" : 3046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3045",
        "source" : "2885",
        "target" : "2910",
        "shared_name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3045,
        "BEND_MAP_ID" : 3045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3044",
        "source" : "2885",
        "target" : "2909",
        "shared_name" : "Dale Gonyea (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3044,
        "BEND_MAP_ID" : 3044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3043",
        "source" : "2885",
        "target" : "2912",
        "shared_name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3043,
        "BEND_MAP_ID" : 3043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3042",
        "source" : "2885",
        "target" : "2908",
        "shared_name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3042,
        "BEND_MAP_ID" : 3042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3041",
        "source" : "2885",
        "target" : "2907",
        "shared_name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3041,
        "BEND_MAP_ID" : 3041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3040",
        "source" : "2885",
        "target" : "2906",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3040,
        "BEND_MAP_ID" : 3040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3039",
        "source" : "2885",
        "target" : "2905",
        "shared_name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin: The Return of Jafar",
        "name" : "Dale Gonyea (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3039,
        "BEND_MAP_ID" : 3039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3038",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3038,
        "BEND_MAP_ID" : 3038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3037",
        "source" : "2884",
        "target" : "2909",
        "shared_name" : "David Friedman (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3037,
        "BEND_MAP_ID" : 3037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3036",
        "source" : "2884",
        "target" : "2912",
        "shared_name" : "David Friedman (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3036,
        "BEND_MAP_ID" : 3036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3035",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3035,
        "BEND_MAP_ID" : 3035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3034",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3034,
        "BEND_MAP_ID" : 3034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3033",
        "source" : "2884",
        "target" : "2906",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3033,
        "BEND_MAP_ID" : 3033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3032",
        "source" : "2884",
        "target" : "2905",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3032,
        "BEND_MAP_ID" : 3032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3031",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3031,
        "BEND_MAP_ID" : 3031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3030",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3030,
        "BEND_MAP_ID" : 3030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3029,
        "BEND_MAP_ID" : 3029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3028",
        "source" : "2884",
        "target" : "2888",
        "shared_name" : "David Friedman (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3028,
        "BEND_MAP_ID" : 3028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3027",
        "source" : "2884",
        "target" : "2887",
        "shared_name" : "David Friedman (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3027,
        "BEND_MAP_ID" : 3027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3026",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3026,
        "BEND_MAP_ID" : 3026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3025",
        "source" : "2884",
        "target" : "2909",
        "shared_name" : "David Friedman (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3025,
        "BEND_MAP_ID" : 3025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3024",
        "source" : "2884",
        "target" : "2912",
        "shared_name" : "David Friedman (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3024,
        "BEND_MAP_ID" : 3024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3023",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3023,
        "BEND_MAP_ID" : 3023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3022",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3022,
        "BEND_MAP_ID" : 3022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3021",
        "source" : "2884",
        "target" : "2906",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3021,
        "BEND_MAP_ID" : 3021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3020",
        "source" : "2884",
        "target" : "2905",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3020,
        "BEND_MAP_ID" : 3020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3019",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3019,
        "BEND_MAP_ID" : 3019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3018",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3018,
        "BEND_MAP_ID" : 3018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3017",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3017,
        "BEND_MAP_ID" : 3017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3016",
        "source" : "2884",
        "target" : "2888",
        "shared_name" : "David Friedman (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3016,
        "BEND_MAP_ID" : 3016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3015",
        "source" : "2884",
        "target" : "2887",
        "shared_name" : "David Friedman (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3015,
        "BEND_MAP_ID" : 3015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3014",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3014,
        "BEND_MAP_ID" : 3014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3013",
        "source" : "2884",
        "target" : "2909",
        "shared_name" : "David Friedman (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3013,
        "BEND_MAP_ID" : 3013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3012",
        "source" : "2884",
        "target" : "2912",
        "shared_name" : "David Friedman (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3012,
        "BEND_MAP_ID" : 3012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3011",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3011,
        "BEND_MAP_ID" : 3011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3010",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3010,
        "BEND_MAP_ID" : 3010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3009",
        "source" : "2884",
        "target" : "2906",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3009,
        "BEND_MAP_ID" : 3009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3008",
        "source" : "2884",
        "target" : "2905",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3008,
        "BEND_MAP_ID" : 3008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3007,
        "BEND_MAP_ID" : 3007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3006",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3006,
        "BEND_MAP_ID" : 3006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3005",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 3005,
        "BEND_MAP_ID" : 3005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3004",
        "source" : "2884",
        "target" : "2888",
        "shared_name" : "David Friedman (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3004,
        "BEND_MAP_ID" : 3004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3003",
        "source" : "2884",
        "target" : "2887",
        "shared_name" : "David Friedman (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 3003,
        "BEND_MAP_ID" : 3003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3002",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3002,
        "BEND_MAP_ID" : 3002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3001",
        "source" : "2884",
        "target" : "2909",
        "shared_name" : "David Friedman (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3001,
        "BEND_MAP_ID" : 3001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3000",
        "source" : "2884",
        "target" : "2912",
        "shared_name" : "David Friedman (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 3000,
        "BEND_MAP_ID" : 3000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2999,
        "BEND_MAP_ID" : 2999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2998",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2998,
        "BEND_MAP_ID" : 2998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2997",
        "source" : "2884",
        "target" : "2906",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2997,
        "BEND_MAP_ID" : 2997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2996",
        "source" : "2884",
        "target" : "2905",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2996,
        "BEND_MAP_ID" : 2996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2995",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 2995,
        "BEND_MAP_ID" : 2995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2994",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 2994,
        "BEND_MAP_ID" : 2994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2993",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 2993,
        "BEND_MAP_ID" : 2993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2992",
        "source" : "2884",
        "target" : "2888",
        "shared_name" : "David Friedman (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 2992,
        "BEND_MAP_ID" : 2992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "source" : "2884",
        "target" : "2887",
        "shared_name" : "David Friedman (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 2991,
        "BEND_MAP_ID" : 2991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2990",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2990,
        "BEND_MAP_ID" : 2990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2989",
        "source" : "2884",
        "target" : "2909",
        "shared_name" : "David Friedman (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2989,
        "BEND_MAP_ID" : 2989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2988",
        "source" : "2884",
        "target" : "2912",
        "shared_name" : "David Friedman (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2988,
        "BEND_MAP_ID" : 2988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2987",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2987,
        "BEND_MAP_ID" : 2987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2986",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2986,
        "BEND_MAP_ID" : 2986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "source" : "2884",
        "target" : "2906",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2985,
        "BEND_MAP_ID" : 2985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2984",
        "source" : "2884",
        "target" : "2905",
        "shared_name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2984,
        "BEND_MAP_ID" : 2984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2983",
        "source" : "2884",
        "target" : "2910",
        "shared_name" : "David Friedman (Liz Callaway) Forget About Love",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Forget About Love",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 2983,
        "BEND_MAP_ID" : 2983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2982",
        "source" : "2884",
        "target" : "2908",
        "shared_name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Out of Thin Air",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 2982,
        "BEND_MAP_ID" : 2982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2981",
        "source" : "2884",
        "target" : "2907",
        "shared_name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Liz Callaway",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (Liz Callaway) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Liz Callaway",
        "voice_actor" : "voice actor",
        "SUID" : 2981,
        "BEND_MAP_ID" : 2981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2980",
        "source" : "2884",
        "target" : "2888",
        "shared_name" : "David Friedman (null) There's a Party Here in Agrabah",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) There's a Party Here in Agrabah",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 2980,
        "BEND_MAP_ID" : 2980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2979",
        "source" : "2884",
        "target" : "2887",
        "shared_name" : "David Friedman (null) Welcome to the Forty Thieves",
        "shared_interaction" : "null",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin and the King of Thieves",
        "name" : "David Friedman (null) Welcome to the Forty Thieves",
        "interaction" : "null",
        "voice_actor" : "voice actor",
        "SUID" : 2979,
        "BEND_MAP_ID" : 2979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2978",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2978,
        "BEND_MAP_ID" : 2978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2977,
        "BEND_MAP_ID" : 2977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2976",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2976,
        "BEND_MAP_ID" : 2976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2975",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2975,
        "BEND_MAP_ID" : 2975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2974",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2974,
        "BEND_MAP_ID" : 2974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2973",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2973,
        "BEND_MAP_ID" : 2973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2972",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2972,
        "BEND_MAP_ID" : 2972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2971",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2971,
        "BEND_MAP_ID" : 2971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2970",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2970,
        "BEND_MAP_ID" : 2970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2969",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2969,
        "BEND_MAP_ID" : 2969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2968",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2968,
        "BEND_MAP_ID" : 2968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2967,
        "BEND_MAP_ID" : 2967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2966",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2966,
        "BEND_MAP_ID" : 2966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2965",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2965,
        "BEND_MAP_ID" : 2965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2964",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2964,
        "BEND_MAP_ID" : 2964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2963",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2963,
        "BEND_MAP_ID" : 2963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2962",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2962,
        "BEND_MAP_ID" : 2962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2961,
        "BEND_MAP_ID" : 2961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2960",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2960,
        "BEND_MAP_ID" : 2960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2959",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2959,
        "BEND_MAP_ID" : 2959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2958",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2958,
        "BEND_MAP_ID" : 2958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2957",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2957,
        "BEND_MAP_ID" : 2957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2956",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2956,
        "BEND_MAP_ID" : 2956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2955",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2955,
        "BEND_MAP_ID" : 2955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2954",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2954,
        "BEND_MAP_ID" : 2954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2953,
        "BEND_MAP_ID" : 2953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2952",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2952,
        "BEND_MAP_ID" : 2952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2951,
        "BEND_MAP_ID" : 2951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2950",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2950,
        "BEND_MAP_ID" : 2950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2949",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2949,
        "BEND_MAP_ID" : 2949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2948",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2948,
        "BEND_MAP_ID" : 2948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2947",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2947,
        "BEND_MAP_ID" : 2947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2946",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2946,
        "BEND_MAP_ID" : 2946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2945",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2945,
        "BEND_MAP_ID" : 2945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2944",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2944,
        "BEND_MAP_ID" : 2944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2943,
        "BEND_MAP_ID" : 2943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2942",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2942,
        "BEND_MAP_ID" : 2942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2941",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2941,
        "BEND_MAP_ID" : 2941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2940",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2940,
        "BEND_MAP_ID" : 2940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2939,
        "BEND_MAP_ID" : 2939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2938",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2938,
        "BEND_MAP_ID" : 2938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2937",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2937,
        "BEND_MAP_ID" : 2937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2936",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2936,
        "BEND_MAP_ID" : 2936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2935",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2935,
        "BEND_MAP_ID" : 2935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2934",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2934,
        "BEND_MAP_ID" : 2934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2933",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2933,
        "BEND_MAP_ID" : 2933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2932",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2932,
        "BEND_MAP_ID" : 2932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2931",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2931,
        "BEND_MAP_ID" : 2931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2930",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2930,
        "BEND_MAP_ID" : 2930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2929,
        "BEND_MAP_ID" : 2929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2928",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2928,
        "BEND_MAP_ID" : 2928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2927,
        "BEND_MAP_ID" : 2927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2926",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2926,
        "BEND_MAP_ID" : 2926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2925",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2925,
        "BEND_MAP_ID" : 2925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2924",
        "source" : "2883",
        "target" : "2901",
        "shared_name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) Prince Ali (Reprise)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2924,
        "BEND_MAP_ID" : 2924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2923",
        "source" : "2883",
        "target" : "2900",
        "shared_name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "shared_interaction" : "Jonathan Freeman",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Jonathan Freeman) You're Only Second Rate(1994)",
        "interaction" : "Jonathan Freeman",
        "voice_actor" : "voice actor",
        "SUID" : 2923,
        "BEND_MAP_ID" : 2923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2922",
        "source" : "2883",
        "target" : "2910",
        "shared_name" : "Tim Rice (Brad Kane) Forget About Love",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Forget About Love",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2922,
        "BEND_MAP_ID" : 2922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "source" : "2883",
        "target" : "2909",
        "shared_name" : "Tim Rice (Brad Kane) Father and Son",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Father and Son",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2921,
        "BEND_MAP_ID" : 2921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2920",
        "source" : "2883",
        "target" : "2912",
        "shared_name" : "Tim Rice (Brad Kane) A Whole New World",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) A Whole New World",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2920,
        "BEND_MAP_ID" : 2920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "source" : "2883",
        "target" : "2908",
        "shared_name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Out of Thin Air",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2919,
        "BEND_MAP_ID" : 2919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2918",
        "source" : "2883",
        "target" : "2907",
        "shared_name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) Nothing In The World (Quite Like A Friend)(1994)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2918,
        "BEND_MAP_ID" : 2918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2917",
        "source" : "2883",
        "target" : "2906",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead (animated)",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2917,
        "BEND_MAP_ID" : 2917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2916",
        "source" : "2883",
        "target" : "2905",
        "shared_name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "shared_interaction" : "Brad Kane",
        "movie" : "movie",
        "Aladdin_Live_Action_" : "Aladdin",
        "name" : "Tim Rice (Brad Kane) One Jump Ahead Reprise-animated",
        "interaction" : "Brad Kane",
        "voice_actor" : "voice actor",
        "SUID" : 2916,
        "BEND_MAP_ID" : 2916,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}